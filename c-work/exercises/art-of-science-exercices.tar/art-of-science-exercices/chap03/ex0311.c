/* 
 * File: ex0311.c
 * --------------
 * This program prints a result of an election.
 */
#include <stdio.h>

void main()
{
	printf("   %-15s  %4d\n","Clinton",3372);
	printf("   %-15s  %4d\n","Brown",596);
	printf("   %-15s  %4d\n","Tsongas",209);
	printf("   %-15s  %4d\n","Others",74);
}