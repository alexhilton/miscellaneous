/*
 * File: ex0314.c
 * --------------
 * this program finds the largest number among a list of integers input
 * from the user. 0 the sentinel signal the end of inputing.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * constant: Sentinel
 * -------------------
 * Sentinel ----- 0, indicates teh end of inputing.
 */
#define Sentinel 0

void main()
{
	int nMax,nValue;

	printf("This program finds the largest integer in a list.\n");
	printf("Enter 0 to end of inputing.\n");
	printf(" ? ");
	nMax = GetInteger();
	if (!nMax) 
		Error("No meaningful integers entered.");
	else 
	{
		while (TRUE)
		{
			printf(" ? ");
			nValue = GetInteger();
			if (!nValue) break;
			if (nMax < nValue)	nMax = nValue;
		}
		printf("The largest number is %d\n",nMax);
	}
}
	