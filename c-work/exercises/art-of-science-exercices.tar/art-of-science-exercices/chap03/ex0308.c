/*
 * File: ex0308.c
 * --------------
 * This program averages numbers, but it reads the number of values
 * first from the user, then dispaly the answer.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

void main()
{
	int i, nValue, nNum, nSum = 0;
	float fAverage;

	printf("This program average a list of integers.\n");
	printf("How many numbers do you have? ");
	nNum = GetInteger();
	for (i = 0;i < nNum;i++)
	{
		printf(" ? ");
		nValue = GetInteger();
		nSum += nValue;
	}
	fAverage = nSum / nNum;
	printf("the result is %f \n", fAverage);
}