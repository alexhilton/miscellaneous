/*
 * File: ex0307.c
 * --------------
 * Caculate average of N numbers, which are input from user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: N
 * ------------
 * N is the number of values that will be summed.
 */
#define N 5

void main()
{
	int i, nSum, nValue;
	float fAverage;

	nSum = 0;
	printf("This program average %d numbers.\n",N);
	for (i = 0;i < N;i++)
	{
		printf(" ? ");
		nValue = GetInteger();
		nSum += nValue;
	}
	fAverage = (float) nSum / N;
	printf("The average is %g\n",fAverage);
}