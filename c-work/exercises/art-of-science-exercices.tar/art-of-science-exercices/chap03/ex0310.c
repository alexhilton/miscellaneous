/*
 * File: ex0310.c
 * ---------------
 * This program prints a tubular squares and cube of [MinLimit,MaxLimit],
 * which are all integers.
 */
#include <stdio.h>

/*
 * Constant: MinLimit, MaxLimit
 * --------- --------- ----------
 * they determine the interval of integers lie in.
 */
#define MinLimit 1
#define MaxLimit 10

void main ()
{
	int i;

	printf("  Number      Square       Cube\n");
	for (i = MinLimit;i <= MaxLimit;i++)
		printf("  %5d  %10d   %8d\n",i,i*i,i*i*i);
}