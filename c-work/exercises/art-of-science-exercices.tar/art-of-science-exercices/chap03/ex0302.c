/*
 * File: ex0302.c
 * --------------
 * This program will display "Hello, world!" ten times on separate lines.
 */
#include <stdio.h>

/*
 * Constant: Times
 * ---------------
 * Times of displaying message.
 */
#define Times 10
void main()
{
	int i = 0;

	for (;i < Times;i++)
		printf("Hello, world!\n");
}