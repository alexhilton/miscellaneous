/*
 * File: ex0304.c
 * --------------
 * This program sums ten float-point numbers.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: CNT
 * -------------
 * The numbers of values will be sumed.
 */
#define CNT 10

void main()
{
	double dValue, dSum;
	int i = 0;
	
	printf("This program will sum ten float-point numbers.\n");
	dSum = 0;
	for (; i < CNT; i++)
	{
		printf("Number ");
		dValue = GetInteger();
		dSum += dValue;
	}
	printf("The total %g\n", dSum);
}
