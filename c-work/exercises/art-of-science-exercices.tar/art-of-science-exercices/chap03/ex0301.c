/*
 * File: ex0301.c
 * --------------
 * This program first reads the number of values and then sums them.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"
void main
()
{
	int nCNT, nTotal, nValue,i;

	nTotal = 0;
	printf("This program sum numbers.\n");
	printf("How many numbers ");
	nCNT = GetInteger();
	for (i = 0;i < nCNT; i++)
	{
		printf("Number ");
		nValue = GetInteger();
		nTotal += nValue;
	}
	printf("The total is %d\n", nTotal);
}