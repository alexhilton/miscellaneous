/*
 * File: ex0305.c
 * --------------
 * This program displays the square tabular of integers in interval [MinLimit, 
 * MaxLimit].
 */
#include <stdio.h>

/*
 * Constant: MinLimit, MaxLimit
 * ----------------------------
 * MinLimit and MaxLimit are the interval's limits that square tabular lay in.
 */
#define MinLimit 1
#define MaxLimit 10

void main()
{
	int i;

	printf("This is square tabular.\n");
	for (i = MinLimit; i < MaxLimit; i++)
		printf("  %d  squared is %d\n",i,i * i);
}