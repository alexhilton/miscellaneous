/*
 * File: ex0313.c
 * --------------
 * This program caculates compound interest rate of N years, which
 * entered by user, then display the accumulated balance after each N
 * years.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "simpio.c"

void main ()
{
	double dStartBalance, dNewBalance, dInterestRate;
	int nYears;

	printf("compount interest rate caculation program.\n");
	printf(" Enter years ");
	nYears = GetInteger();
	printf(" Starting balance ");
	dStartBalance = GetReal();
	printf("interest rate as percentage ");
	dInterestRate = GetReal();
	dNewBalance = dStartBalance * pow((1 + dInterestRate),nYears);
	printf("Balance after %d years is %g\n", nYears,dNewBalance);
}