/*
 * File: ex0306.c
 * --------------
 * This program sums the number of values between [1,100].
 */
#include <stdio.h>

/*
 * Constant: MinLimit, MaxLimit
 * -------- --------- ----------
 * The limits of number interval.
 */
#define MinLimit 1
#define MaxLimit 100

void main()
{
	int i,nSum = 0;

	printf("Sums of numbers\n");
	for(i = MinLimit; i <= MaxLimit; i++)
		nSum += i;
	printf("the total %d\n",nSum);
}