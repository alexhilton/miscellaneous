/*
 * File: ex0303.c
 * --------------
 * This program will generate a line like:
 * Tomorrow and tomorrow and tomorrow.
 */
#include <stdio.h>
void main()
{
	int i=0;

	printf("Tomorrow ");
	for (;i < 2; i++)
		printf("and tomorrow ");
	printf("\n");
}