/*
 * file: ex0309.c
 * --------------
 * This program reads a list of integers untill the sentinel -1.
 * Then display the average of the values entered so far.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: Sentinel -1
 * ----------------------
 * Sentinel indicates the end sign of inputing data.
 */
#define Sentinel -1

void main()
{
	int nValue, nSum, nCNT;
	float fAverage;

	nSum = 0;
	nCNT = 0;
	printf("This program averages a list of integers entered so far.\n");
	printf("Enter -1 to end of inputing.\n");
	while (TRUE)
	{
		printf(" ? ");
		nValue = GetInteger();
		if (nValue == Sentinel) break;
		nSum += nValue;
		nCNT++;
	}
	if (!nCNT) Error("No meaningful integers entered.");
	fAverage = nSum / nCNT;
	printf("The result is %f\n",fAverage);
}