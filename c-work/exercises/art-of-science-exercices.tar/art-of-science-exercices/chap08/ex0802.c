/*
 * File: ex0802.c
 * --------------
 * this function will generate a random even integer between
 * UpperLimit and LowerLimit;
 */
#include <stdio.h>

#include "random.c"

/* main program */
main ()
{
	int num;
	const int LowerLimit = 2;
	const int UpperLimit = 100;

	Randomize();
	num = RandomInteger(LowerLimit / 2, UpperLimit / 2);

	printf("\n the number is %d\n", 2 * num);
}