/*
 * File: ex0805.c
 * --------------
 * this file simulates flipping the coins, and stops if there are
 * three consective heads appearance.
 */
#include <stdio.h>
#include <stdlib.h>

#include "genlib.c"
#include "random.c"

/* function prototype */
int HeadsOrTails(void);
void FlipCoin(void);

/* main program */
main ()
{
	printf("\n Flipping coin simulation program .\n");
	FlipCoin();
}

/*
 * Function: FlipCoin
 * Usage: FlipCoin();
 * ------------------
 * this function simulates flipping coins until there three consective
 * heads.
 */
void FlipCoin(void)
{
	int sum, count;

	sum = 0;
	count = 0;

	while (TRUE)
	{
		count++;
		sum += HeadsOrTails();
		if (sum == 3)
		{
			printf("It took %d flips to get heads 3 consective times",
					count);
			break;
		}
		if (count % 3 == 0)
		{
			sum = 0;
		}
	}
}

/*
 * Funtion: HeadsOrTails
 * Usage: count = HeadsOrTails();
 * ------------------------------
 * this function flips a coin once, returning 1 if it is heads, otherwise
 * returning 0 instead.
 */
int HeadsOrTails(void)
{
	int result;

	result = 0;

	if (rand() <= RAND_MAX / 2)
	{
		printf("\nHeads\n");
		result = 1;
	}
	else
	{
		printf("\nTails\n");
	}

	return (result);
}