/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * exercise tweleve of chap 08.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include "random.h"


/* Private function prototype(s) */

/* Main program */
int main( int argc, char **argv )
/* End $Source$ */
