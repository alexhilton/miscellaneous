/*
 * File: ex0808.c
 * --------------
 * this program provides an example of an educational applications,
 * which presents either addition or substraction with random integer
 * numbers less than 20.
 */
#include <stdio.h>
#include <stdlib.h>

#include "genlib.c"
#include "random.c"
#include "simpio.c"
#include "array.c"

/* constant: QuestionNumber
 * -------------------------
 * QuestionNumber -- number of questions to be asked when running
 * application.
 */
#define QuestionNumber  5

/* Function prototypes */
void Encourage(void);
int GenerateNum(void);
char GenerateSign(void);
int GetUserAnswer(void);
void GiveAnswer(int correctAnswer);
void GiveInstruction(void);
int GiveQuestion(void);
bool IsCorrect(int correctAnswer, int userAnswer);
void TryAgain(int correctAnswer);

/* main program */
main ()
{
	int i, correctAnswer, userAnswer;

	GiveInstruction();

	for (i = 0; i < QuestionNumber; i++)
	{
		correctAnswer = GiveQuestion();
		userAnswer = GetUserAnswer();
		if (!IsCorrect(correctAnswer, userAnswer))
		{
			TryAgain(correctAnswer);
		}
		else
		{
			Encourage();
		}
	}
}

/*
 * Function: GiveQuestion
 * Usage: correctAnswer = GiveQuestion();
 * --------------------------------------
 * this fucntion will give user a question which either addition
 * or substruction operation with random integer numbers less than
 * 20. And return the correct answer of the question for further
 * checking.
 */
int GiveQuestion(void)
{
	int a, b;
	char sign;

	Randomize();
	a = GenerateNum();
	b = GenerateNum();
	sign = GenerateSign();

	if (a < b)
	{
		Swap(&a, &b);
	}

	/* display the question */
	printf("\n What is %d %c %d ? ", a, sign, b);

	/* return the value of correct answer */
	switch (sign)
	{
		case '+':
		{
			return (a + b);
		}
		case '-':
		{
			return (a - b);
		}
		defaulf:
		{
			break;
		}
	}
}

/*
 * Function: GenerateNum
 * Usage: num = GeneateNum();
 * --------------------------
 * this function gnerates a random integer less than 20;
 */
int GenerateNum(void)
{
	return (RandomInteger(1, 20));
}

/*
 * Function: GenerateSign
 * Usage: sign = GenerateSign();
 * -----------------------------
 * ths  function generates either addiation sign '+' or substraction
 * sign '-' randomly.
 */
char GenerateSign(void)
{
	char result;

	result = '-';

	if (rand() < RAND_MAX / 2)
	{
		result = '+';
	}

	return (result);
}

/*
 * Function: IsCorrect
 * Usage: if (IsCorrect(correctAnswer, userAnswer)) ...
 * ----------------------------------------------------
 * this function returns TRUE if the user's answer is right. That
 * is, if userAnswer equals to correctAnswer.
 */
bool IsCorrect(int correctAnswer, int userAnswer)
{
	return (userAnswer == correctAnswer);
}

/*
 * function: GetUserAnswer
 * Usage: userAnswer = GetUserAnswer();
 * ------------------------------------
 * this fucntion returns the user's answer, input by user.
 */
int GetUserAnswer(void)
{
	int result;

	result = GetInteger();

	return (result);
}

/*
 * Function: GiveInstruction
 * Usage: giveInstruction();
 * -------------------------
 * this procedure gives instructions about the application to users.
 */
void GiveInstruction(void)
{
	printf("\n Welcome to Math quiz.\n");
	printf("\n You've got five question of simple additions\n");
	printf("\n or substractions. Answer each question at the end\n");
	printf("\n of the question, you have at most three chances to \n");
	printf("\n answer each question.\n");
	printf("\n Good Luck!\n");
}

/*
 * Function: Encourage
 * Usage: Encourage();
 * -------------------
 * tis procedure prints the encouraging words to user if he got
 * right answer.
 */
void Encourage(void)
{
	int seed;

	seed = RandomInteger(1, 4);
	switch (seed)
	{
		case 1:
		{
			printf("\n Congratulations! You got it!\n");
			break;
		}
		case 2:
		{
			printf("\n Correct!\n");
			break;
		}
		case 3:
		{
			printf("\n Well done! You got it!\n");
			break;
		}
		case 4:
		{
			printf("\n You got it. That's the answer!\n");
			break;
		}
		default:
		{
			break;
		}
	}
}

/*
 * Function: TryAgain
 * Usage: TryAgain();
 * ------------------
 * this function gives the user another chance if he failed to
 * get the right answer first time.
 */
void TryAgain(int correctAnswer)
{
	int userAnswer;
	printf("\n That's incorrect! Try a different answer: ");
	userAnswer = GetUserAnswer();
	if (!IsCorrect(correctAnswer, userAnswer))
	{
		printf("\n That's incorrect! Try a different answer: ");
		userAnswer = GetUserAnswer();
		if (!IsCorrect(correctAnswer, userAnswer))
		{
			GiveAnswer(correctAnswer);
		}
		else
		{
			Encourage();
		}
	}
	else
	{
		Encourage();
	}
}

/*
 * Function: giveAnswer
 * Usage: GiveAnswer(correctAnswer);
 * ----------------------------------
 * tis procedure displays the correct answer to the user.
 */
void GiveAnswer(int correctAnswer)
{
	printf("\n No, the answer is %d\n", correctAnswer);
}
