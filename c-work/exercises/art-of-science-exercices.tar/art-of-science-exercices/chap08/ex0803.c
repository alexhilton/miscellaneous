/*
 * File: ex0804.c
 * --------------
 * this program generates one of fifty-two cards in a Poker.
 * Sample: Queen of Spades.
 */
#include <stdio.h>

#include "genlib.c"
#include "random.c"

/*
 * Enumeration types: Rank_t, Suit_t
 * ---------------------------------
 * Rank_t -- is the rank of the cards;
 * Suit_t -- is the suit of the cards.
 */
typedef enum {Ace = 1, Two, Three, Four, Five,
		  Six, Seven, Eight, Nine, Ten, Jack,
		  Queen, King} Rank_t;
typedef enum {Clubs, Diamonds, Hearts, Spades} Suit_t;

/* function prototype */
Rank_t GenerateRank(void);
Suit_t GenerateSuit(void);
string RankName(Rank_t rank);
string SuitName(Suit_t suit);

/* main program */
main ()
{
	Rank_t rank;
	Suit_t suit;
	Randomize();
	rank = GenerateRank();
	suit = GenerateSuit();

	printf("\n %s of %s\n", RankName(rank), SuitName(suit));
}

/*
 * Function: GenerateRank
 * Usage: rank = GenerateRank();
 * ------------------------------
 * This function returns a random rank between Ace and King.
 */
Rank_t GenerateRank(void)
{
	Rank_t rank;

	Randomize();
	rank = RandomInteger(Ace, King);

	return (rank);
}

/*
 * function: GenerateSuit
 * Usage: suit = GenerateSuit();
 * -----------------------------
 * tis function returns a random suit.
 */
Suit_t GenerateSuit(void)
{
	Suit_t suit;

	Randomize();
	suit = RandomInteger(Clubs, Spades);

	return (suit);
}

/*
 * Function: RankName
 * Usage: rankName = RankName(rank);
 * ----------------------------------
 * this function returns the name of rank.
 */
string RankName(Rank_t rank)
{
	switch (rank)
	{
		case Ace:
		{
			return ("Ace");
		}
		case Two:
		{
			return ("2");
		}
		case Three:
		{
			return ("3");
		}
		case Four:
		{
			return ("4");
		}
		case Five:
		{
			return ("5");
		}
		case Six:
		{
			return ("6");
		}
		case Seven:
		{
			return ("7");
		}
		case Eight:
		{
			return ("8");
		}
		case Nine:
		{
			return ("9");
		}
		case Ten:
		{
			return ("10");
		}
		case Jack:
		{
			return ("Jack");
		}
		case Queen:
		{
			return ("Queen");
		}
		case King:
		{
			return ("King");
		}
		default:
		{
			break;
		}
	}
}

/*
 * Function: SuitName
 * Usage: suitName = SuitName(Suit_t suit);
 * ----------------------------------------
 * this function returns a random suit.
 */
string SuitName(Suit_t suit)
{
	switch (suit)
	{
		case Clubs:
		{
			return ("Clubs");
		}
		case Diamonds:
		{
			return ("Diamonds");
		}
		case Hearts:
		{
			return ("Hearts");
		}
		case Spades:
		{
			return ("Spades");
		}
		default:
		{
			break;
		}
	}
}
