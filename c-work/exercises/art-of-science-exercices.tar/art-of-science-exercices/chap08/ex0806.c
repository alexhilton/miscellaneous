/*
 * File: ex0806.c
 * --------------
 * this program caculates pi with Monte Carlo method.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "random.c"

/* function prototype */
double CaculatePi(const int Epsilon);

/* main progra */
main ()
{
	const int Epsilon = 10000;
	printf("\nPi approximate value\n");
	printf(" %g\n", CaculatePi(Epsilon));
}

/*
 * function: CaculatePi
 * usgae: pi = CaculatePi(Epsilon);
 * --------------------------------
 * this function return an approximate value of Pi in the method of
 * Monte Carlo method.
 */
double CaculatePi(const int Epsilon)
{
	int count, i;
	double x, y; /* two coordinates, x-axis and y-axis. */

	count = 0;

	for (i = 0; i < Epsilon; i++)
	{
		x = RandomReal(-1, 1);
		y = RandomReal(-1, 1);
		if (x * x + y * y < 1)
		{
			count++;
		}
	}

	return (4 * count / (double) Epsilon);
}