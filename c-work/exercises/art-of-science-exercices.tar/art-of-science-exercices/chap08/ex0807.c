/*
 * file: ex0807.c
 * --------------
 * this program simulates the process of decaying of atoms.
 */
#include <stdio.h>
#include <stdlib.h>

/* function prototype */
int AtomLeft(int previousNum);

/* main program */
main ()
{
	int year, currentNum;

	currentNum = 10000;
	year = 0;

	printf("\n  Year       Atoms Left\n");
	printf("\n -------    -------------\n");

        do
        {
		printf("\n   %3d           %5d\n", year, currentNum);
		year++;
		currentNum = AtomLeft(currentNum);
	  } while (currentNum > 0);
	printf("\n   %3d	         %5d\n", year, currentNum);

}

/*
 * Function: AtomLeft
 * Usage: currentNum = AtomLeft(previousNum);
 * ------------------------------------------
 * this function returns the current number of atoms left after a
 * year of decaying among previousNum atoms.
 */
int AtomLeft(int previousNum)
{
	int count, i;

	count = 0;

	for (i = 0; i < previousNum; i++)
	{
		if (rand() < RAND_MAX / 2)
		{
			count++;
		}
	}
	return (count);
}