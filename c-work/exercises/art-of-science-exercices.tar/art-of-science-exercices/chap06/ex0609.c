/*
 * File: ex0609.c
 * --------------
 * this program caculates pi using geometrical methods.that is
 * the area of one quarter of a circle whose radius is two units
 * approximately equals to pi. and the area can be summed as sum
 * of Num rectangs.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"

/* function prototype */
double CaculatePi(const int Epsilon);

/* main program */
main ()
{
	const int Epsilon = 10000;

	double pi;

	pi = CaculatePi(Epsilon);
	printf("\n Pi is %g\n", pi);
}

/*
 * function: CaculatePi
 * Usage: pi = CaculatePi(Epsilon);
 * --------------------------------
 * this function returns an approximate value of pi, making by
 * approximate area methods.
 */
double CaculatePi(const int Epsilon)
{
	double width, height, xAxis, area, sum, radius;
	int i;

	radius = 2;
	width = radius / (double) (Epsilon + 1);
	xAxis = width / 2.0;
	area = 0;
	sum = 0;
	i = 0;

	for (i = 0; i < Epsilon; i++)
	{
		height = sqrt(radius * radius - xAxis * xAxis);
		area = width * height;
		sum += area;
		xAxis += width;
	}

	return (sum);
}

