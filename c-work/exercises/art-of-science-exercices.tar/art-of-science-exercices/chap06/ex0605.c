/*
 * File: ex0605.c
 * --------------
 * This program caculates the approximately cube root of an real number.
 */
#include <stdio.h>
#include <math.h>

#include "simpio.c"
#include "genlib.c"

/* constant: Epsilon
 * -----------------
 * Epsilon -- the error tolerance.
 */
#define EPSILON 0.000001
/* function prototype */
double CubeRoot(double x);
bool ApproximatelyEqual(double x, double y);

/* main program */
main ()
{
	double x;

	printf("\n Cube root program.\n");
	printf(" ? ");

	x = GetReal();

	printf(" its cube root is %g \n", CubeRoot(x));
}

/*
 * Function: CubeRoot
 * Usage: root = CubeRoot(x);
 * --------------------------
 * This function returns the approximately cube root of x.
 */
double CubeRoot(double x)
{
	double root;

	if (x == 0) return (0);
	if (x < 0) Error("Sqrt called with negative argument %g",x);
	root = x;
	while (!ApproximatelyEqual(x, root * root))
	{
		root = (root + x / root) / 2;
	}
	return (root);
}

/*
 * Function: ApproximatelyEqual()
 * Usage: if (ApproximatelyEqual(x,y)) ...
 * ----------------------------------------
 * the two argument are approximately equal, if
 * the absolute value of the difference between the
 * two numbers divided by the smaller of their absolute vlues is
 * less than some constant EPSILON.
 * that can be described in Mathematical way:
 *
 *     |x - y|
 * --------------- < EPSILON
 *   min(|x|,|y|)
 *
 * the EPSILON can be reset to meet any accuracy.
 */
bool ApproximatelyEqual(double x,double y)
{
	/* dist -- is the distance between x,y or |x-y| in Math*/
	/* dmin -- is the less of the absolute value of the two argements */
	double dist,dmin;

	dist = fabs(x - y);
	dmin = fabs(x);

	if (fabs(x) > fabs(y))
	{
		dmin = fabs(y);
	}
	return ((dist / dmin) < EPSILON);
}