/*
 * File: ex0608.c
 * --------------
 * This program caculates Pi approximately.
 */
#include <stdio.h>

#include "genlib.c"

/* function prototype */
double CaculatePi(const double Epsilon);

/* main program */
main ()
{
	const double Epsilon = 0.0000000001;
	double pi;

	pi = CaculatePi(Epsilon);
	printf("\n The approximate Pi is %g\n", pi);
}

/*
 * function: CaculatePi
 * Usage: pi = CaculatePi(Epsilon);
 * --------------------------------
 * the function returns a approximate value of pi.
 */
double CaculatePi(const double Epsilon)
{
	double term, sum, coeff, exponent, product;
	int k, i;

	term = 1.0;
	sum = 1 / 2.0;
	i = 2.0;
	k = 0;
	coeff = 1.0;
	exponent = 1 / 2.0;
	product = 1.0;

	while (term > Epsilon)
	{
		k = 2 * i - 1;
		coeff =  1.0 / k;
		product *= (double) (k - 2) / (k - 1);
		exponent *= (double) (1 / 2.0) * (1 / 2.0);
		term = coeff * product * exponent;
		sum += term;
		i++;
	}

	return (6 * sum);
}
