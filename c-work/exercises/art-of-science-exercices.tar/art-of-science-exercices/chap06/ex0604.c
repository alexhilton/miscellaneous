/*
 * File: ex0604.c
 * --------------
 * This program finds out all the Perfect Numbers between 1 and 9999.
 */
#include <stdio.h>

#include "genlib.c"

/*
 * Constants: UPPER_LIMIT, LOWER_LIMIT
 * ------------------------------------
 * UPPER_LIMIT -- the upper limit of the numbers.
 * LOWER_LIMIT --  the lower limit of the numbers.
 */
#define UPPER_LIMIT   9999
#define LOWER_LIMIT      2

/* function prototypes */
bool IsPerfect(const int num);

/* main program */
main ()
{
	int num;

	printf(" The perfect numbers between %d and %d are:\n\n",
			LOWER_LIMIT, UPPER_LIMIT);

	for (num = LOWER_LIMIT; num <= UPPER_LIMIT; num++)
	{
		if (IsPerfect(num))
		{
			printf("  %d  ", num);
		}
	}
	printf("\n");
}

/*
 * Function: IsPerfect
 * Usage: if (IsPerfect(num)) ...
 * -------------------------------
 * This function returns True if num is a perfect number.
 */
bool IsPerfect(const int num)
{
	int i, sum;

	sum = 1;

	for (i = 2; i < num; i++)
	{
		if (num % i == 0)
		{
			sum += i;
		}
	}
	return (num == sum);
}


