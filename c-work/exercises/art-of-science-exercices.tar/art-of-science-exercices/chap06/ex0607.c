/*
 * file: ex0607.c
 * ---------------
 * caculate Pi with several different methods, this is one of them.
 */
#include <stdio.h>

/* Function prototype */
double CaculatePi(const int Epsilon);

/* main program */
main ()
{
	const int Epsilon = 10000;

	printf(" Pi caculating.\n");
	printf(" The approximate Pi is %g\n", CaculatePi(Epsilon));
}


double CaculatePi(const int Epsilon)
{
	int sign = -1;

	int i;
	double sum, deno, term;

	i = 2;
	sum = 1;
	term = 1;
	deno = 3;

	while (i <= Epsilon)
	{
		term = sign / deno;
		i++;
		deno += 2;
		sum += term;
		sign *= -1;
	}
	return (4 * sum);
}
