/*
 * File: ex0602.c
 * ---------------
 * this program will find all the prime factors of an integer number
 * which is greater than 1. The factors are all prime numbers, and can
 * be repeated.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "simpio.c"

/* Function prototypes */
bool IsPrime(int num);
int Prime(const int num);
void PrimeFactorize(const int num);

/* main program */
main ()
{
	int num;

	printf(" Prime Factorization Program.\n");
	printf(" Input the number: ");
	num = GetInteger();

	PrimeFactorize(num);
}

/*
 * Function: PrimeFactorize
 * Usage: PrimeFactorize(num);
 * ---------------------------
 * This function factorize the num, but make all the factors are primes.
 * then it will prints all the prime factors.
 */
void PrimeFactorize(const int num)
{
	int i, temp, primeNum;

	i = 1;
	temp = num;

	while (temp > 1)
	{
		primeNum = Prime(i);
		if (temp % primeNum == 0)
		{
			printf(" %d ", primeNum);
			temp /= primeNum;
		}
		else
		{
			i++;
		}
	}
}

/*
 * Function: Prime
 * Usage: primeNum = Prime(i);
 * ---------------------------
 * This fucntion will return the ith prime starting with 2 as the
 * first. For example, Prime(3) returns 5, which is the 3rd prime.
 * And here, we assume that the prime array starts with 2.
 */
int Prime(const int num)
{
	int i, count;

	i = 3;
	count = 2;

	if (num == 1)
	{
		return (2);
	}
	else
	{
		while (count <= num)
		{
			if (IsPrime(i))
			{
				count++;
			}
			i += 2;
		}
		return (i - 2);
	}
}

/*
 * Function: IsPrime
 * Usage: if (IsPrime(i)) ...
 * --------------------------
 * This function returns true if i is a prime.
 */
bool IsPrime(int num)
{
	int i, root;

	root = sqrt(num) + 1;
	if (num <= 1) return (FALSE);
	if (num == 2) return (TRUE);
	if (num % 2 == 0) return (FALSE);

	for (i = 3; i <= root; i aa+= 2)
	{
		if (num % i == 0)
		{
			return (FALSE);
		}
	}
	return (TRUE);
}
