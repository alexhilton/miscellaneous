/*
 * File: ex0606.c
 * --------------
 * This is the exercise six of chap six, in <The Art and Science of c>.
 */
#include <stdio.h>

#include "genlib.c"

typedef enum { Mercury, Venus, Earth, Mars,
		   unknown, Jupiter, Saturn, Uranus } Planet_t;
/* function prototype */
double Distance(Planet_t planet);
string PlanetName(Planet_t planet);
void PrintPlanet(Planet_t planet);

/* main */
main ()
{
	Planet_t planet;

	for (planet = Mercury; planet <= Uranus; planet++)
	{
		PrintPlanet(planet);
	}
}

/*
 * Function: PrintPlanet
 * Usage: PrintPlanet(planet);
 * ---------------------------
 * This procedure pritns the Bobe's Table.
 */
void PrintPlanet(Planet_t planet)
{
	printf(" %-14s ", PlanetName(planet));
	printf(" %4.1f AU\n", Distance(planet));
}

/*
 * Function: Distance
 * Usage: dist = Distance(planet);
 * --------------------------------
 * this function returns the distance of the planet in the form of
 * AU (Astronamical Unit).
 */
double Distance(Planet_t planet)
{
	int i, bTerm;
	double distance;

	i = 0;
	bTerm = 3;
	distance = 0;

	if (planet == Mercury)
	{
		bTerm = 1;
	}
	if (planet == Venus)
	{
		bTerm = 3;
	}
	for (i = Earth; i <= planet; i++)
	{
		bTerm *= 2;
	}
	distance = (4 + bTerm) / 10.0;
	return (distance);
}

/*
 * Function: PlanetName
 * Usage: name = PlanetName(planet);
 * ---------------------------------
 * This function returns the name of planet.
 */
string PlanetName(Planet_t planet)
{
	switch (planet)
	{
		case 0:
		{
			return ("Mercury");
		}
		case 1:
		{
			return ("Venus");
		}
		case 2:
		{
			return ("Earth");
		}
		case 3:
		{
			return ("Mars");
		}
		case 4:
		{
			return ("unknown");
		}
		case 5:
		{
			return ("Jupiter");
		}
		case 6:
		{
			return ("Saturn");
		}
		case 7:
		{
			return ("Uranus");
		}
		default:
		{
			break;
		}
	}
}