/*
 * file: ex0610.c
 * --------------
 * tis program caculates exponent with series expansion method.
 */
#include <stdio.h>

/* function prototype */
double CaculateExp(const double Epsilon);

/* main program */
main ()
{
	const double Epsilon = 1e-10;

	double exp;

	exp =  CaculateExp(Epsilon);
	printf(" exponent is approximately %g\n", exp);
}

/*
 * Function: CaculateExp
 * Usage: exp = CaculateExp(Epsilon);
 * ----------------------------------
 * this function returns an approximate value of exponent.
 */
double CaculateExp(const double Epsilon)
{
	double term, factorial, exponent;
	int k;

	term = 1.0;
	exponent = 1.0;
	factorial = 1;
	k = 1;

	while (term > Epsilon)
	{
		factorial *= k;
		term = 1.0 / factorial;
		exponent += term;
		k++;
	}

	return (exponent);
}
