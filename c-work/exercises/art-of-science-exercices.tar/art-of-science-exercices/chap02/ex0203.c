/*
 * File: ex0203.c
 * ------ -------
 * Exercise three of chap two.
 * This program converts inches and feet into centemeters.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constants: InchOfFoot, CMOfInch.
 * ------ ------- -------- ---------
 * InchOfFoot is carray from inch to foot, equaling 12, meaning
 * 1 foot = 12 inches.
 * CMOfInch equals to 2.54, meaning 1 inch = 2.54 cm.
 */
#define InchOfFoot 12
#define CMOfInch 2.54

/* Main program */
void main ()
{
	double dFeet, dInches, dCM;

	printf("This program converts feet and inches to cm.\n");
	printf("The number of feet: ");
	dFeet = GetReal();
	printf("The number of inches: ");
	dInches = GetReal();
	dCM = (dFeet * InchOfFoot + dInches) * CMOfInch;
	printf("The corresponding length is %g cm \n",dCM);
}