/*
 * File: ex0206.c
 * --- --- --- ---
 * exercise six of chap two
 * This program computes the area of a circle, whose radius input from user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/* constant: PI , which is circuirate */
#define PI 3.14159
void main ()
{
	double dRadius, dArea;

	printf("Area of a circle computation program.\n");
	printf("Radius: ");
	dRadius = GetReal();
	dArea = PI * dRadius * dRadius;
	printf("Area is %g\n",dArea);
}