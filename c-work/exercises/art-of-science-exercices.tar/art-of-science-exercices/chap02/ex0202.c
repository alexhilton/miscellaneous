/*
 * File: ex0202.c
 * ---- ---- -----
 * This is the exercise two of chapter two in <The Art and Science of C>
 * by Eric. S. Roberts.
 * The function of this program is to caculate the area of an triangular,
 * which bound and height recieved from the user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/* main program */
void main()
{
	double dBound, dHeight, dArea;

	printf("This program caculates the area of a triangular.\n");
	printf("Enter bound: \n");
	dBound = GetReal();
	printf("Enter height:\n");
	dHeight = GetReal();
	dArea = (dBound * dHeight) / 2.0;
	printf("The area of this triangular is %g \n", dArea);
}