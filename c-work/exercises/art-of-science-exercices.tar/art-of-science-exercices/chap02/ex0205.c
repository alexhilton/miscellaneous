/*
 * File: ex0205.c
 * -- ------------
 * this program caculates interest rate based on start balance and 
 * interest rate input from user, then display the new balance after
 * two years.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: NYears
 * ----------------
 * This constant is the years of account been saving.
 */
#define NYears 2
void main ()
{
	double dStartBalance, dInterestRate, dNewBalance;

	printf("Interest Rate caculation program. \n");
	printf("starting balance: ");
	dStartBalance = GetReal();
	printf("Annul interest rate as percentage ");
	dInterestRate = GetReal();
	dNewBalance = dStartBalance * pow((1 + dInterestRate),NYears);
	printf("New balance after two years: %g \n",dNewBalance);
}