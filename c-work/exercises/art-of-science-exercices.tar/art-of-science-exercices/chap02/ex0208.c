/*
 * File: ex0208.c
 * --- ---- ---- --
 */
#include <stdio.h>
void main ()
{
	int result;
	result = 4+9-2*16+1/3*6-67+8*2-3+26-1/34+3/7+2-5;
	printf("%d\n",result);
}
