/*
 * File: ex0210.c
 * --------------
 * This program averages four integers, input by user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

void main ()
{
	int a,b,c,d;
	float fAverage;

	printf("Average four integers.\n");
	printf("1st number ");
	a = GetInteger();
	printf("2nd number ");
	b = GetInteger();
	printf("3rd number ");
	c = GetInteger();
	printf("4th number ");
	d = GetInteger();
	(float) fAverage = (a + b + c + d) / 4;
	printf("Tha average %.2f\n",fAverage);
}
