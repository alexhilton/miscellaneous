/*
 * File: ex0204.c
 * ----- ------ ---
 * This file is exercise four of chap two
 * Its function is interest rate caculation. The program first reads
 * two numbers from the user, an account balance and interest rate.
 * Then display the new balance after a year.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"
void main ()
{
	double dStartBalance, dInterestRate,dNewBalance;

	printf("Interest caculation program.\n");
	printf("Starting balance ");
	dStartBalance = GetReal();
	printf("Annul interest rate as percentage ");
	dInterestRate = GetReal();
	dNewBalance = dStartBalance * (1 + dInterestRate);
	printf("Balance after a year is %g\n",dNewBalance);
}