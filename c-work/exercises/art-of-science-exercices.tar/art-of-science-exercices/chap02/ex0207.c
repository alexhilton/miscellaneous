/*
 * File: ex0207.c
 * --------------
 * This program converts a temperature in degrees Fahrenheit to the corresponding
 * degrees in Celsius.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

void main()
{
	int nFahrenheit, nCelsius;
	printf("Program to convert Fahrenheit to Celsius.\n");
	printf("Fahrenheit degrees ");
	nFahrenheit =  GetInteger();
	(int) nCelsius = 5 * (nFahrenheit - 32) / 9;
	printf("The corresponding Celsius is %d \n",nCelsius);
}
