/*
 * File: ex0209.c
 * --------------
 * This program couverts metric in kilogram to the corresponding weight
 * in English ounces and pounds
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: PoundOfKg, OunceOfPound
 * -------- ---------- -------------
 * PoundOfKg equals 2.2, meaning 1 Kg = 2.2 pounds
 * OunceOfPound is 16, meaning 1 pound = 16 ounces
 */
#define PoundOfKg 2.2
#define OunceOfPound 16

void main ()
{
	double dKg, dPound, dOunce;

	printf("Metric weight convertion program.\n");
	printf("Enter Kg ------Kilogram ");
	dKg = GetReal();
	dPound = PoundOfKg * dKg;
	dOunce = OunceOfPound * dPound;
	printf("The corresponding pounds %g\n",dPound);
	printf("The corresponding ounces %g\n",dOunce);
}
