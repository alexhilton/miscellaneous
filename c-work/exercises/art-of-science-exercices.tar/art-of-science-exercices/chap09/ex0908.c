/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * exercise eight of chap nine.
 * A program implementes encoding a string with letter-subsitution cypher.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Private function prototype(s) */
static char *encode(
  char *str,
  int key
);
static char cypher(
  char ch,
  int key
);

/* Main program */
int main( int argc, char **argv )
{
  char *str;
  int key = 5;

  str = ( char * ) malloc( 81 );
  printf( "This program encodes a message using a cyclic cipher.\n " );
  printf( "enter the numeric key: " );
  scanf( "%d", &key );
  printf( "enter a message: " );
  scanf( "%s", str );
  printf( "Encoded message: %s\n", encode( str, key ) );
  free( str );
  return ( 0 );
}


/*
 * Function: encode
 * Usage: code = encode( str );
 *
 * This function encrypts a string with letter subsitution cypher.
 */
static char *encode(
  char *str,
  int key
) {
  char *p, *q;
  char *result;

  result = ( char * ) malloc( strlen ( str ) );
  p = str;
  q = result;

  for ( ; *p; p++, q++ ) {
    *q = cypher( *p, key );
  }

  return ( result );
}

/*
 * Function: cypher
 * Usage: c = cypher( ch, key );
 *
 * This function returns a cyclic cypher letter subsitution of ch.
 */
static char cypher(
  char ch,
  int key
) {
  ( char ) ch += key;
  if ( ( ch > 'Z' && ch < 'a' ) || ch > 'z' ) {
    ch -= 26;
  }

  return ( ch );
}
/* End $Source$ */
