/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * exercise two of chap 09.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Private function prototype(s) */

/* Main program */
int main( int argc, char **argv )
/* End $Source$ */
