/*
 * $Header: /root/c-work/chap10/ex1012.c,v 1.1 2007/12/26 13:30:30 root Exp root $
 *
 * Hitlion.Warrior.King				$Date: 2007/12/26 13:30:30 $
 *
 * exercise twelve of chap 10.
 * A program to test fill interface.
 *
 * Revision History
 * $Log: ex1012.c,v $
 * Revision 1.1  2007/12/26 13:30:30  root
 * Initial revision
 *
 */
static const char rcsid[] = "$Id: ex1012.c,v 1.1 2007/12/26 13:30:30 root Exp root $";

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fill.h"

/* Priate function prototypes */
static int is_prime(
  int n
);

static char *gen_str(
  void
);

/* Main program */
int main( int argc, char **argv )
{
  char *str;

  str = gen_str();
  set_margin( 55 );
  printf( "The primes between 0 and 200 are:\n" );
  print( str );
  return ( 0 );
}


static int is_prime(
  int n
) {
  int i;
  int root;

  if ( n <= 1 ) {
    return ( 0 );
  }
  root = sqrt( n ) + 1;

  for ( i = 2; i < root; i++ ) {
    if ( n % i == 0 ) {
      return ( 0 );
    }
  }
  return ( 1 );
}

static char *gen_str(
  void
) {
  char *str;
  char *n_name;
  int n;

  str = ( char * ) malloc( 256 );
  for ( n = 1; n <= 200; n += 2 ) {
    if ( is_prime( n ) ) {
      sprintf( n_name, "%d", n );
      strcat( str, n_name );
      strcat( str, ", " );
    }
  }

  free( n_name );
  return ( str );
}
/* End $Source: /root/c-work/chap10/ex1012.c,v $ */
