/*
 * t-scan.c --  testing scanner.h interface.
 */
#include <stdio.h>
#include <stdlib.h>

#include "scanner.h"

int main( void )
{
  char *msg;
  char *token;

  msg = ( char * )  malloc( 80 );
  
  printf( "input a line: " );
  gets( msg );

  init_scanner( msg );
  while ( !at_end() ) {
    token = get_next_token();
    printf( "\n token: '%s'\n", token );
  }

  return ( 0 );
}
