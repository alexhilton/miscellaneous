/*
 * file: ex0409.c
 * --------------
 * The program caculate Fibonacci array.
 */
#include <stdio.h>

/*
 * constant: UPPERLIMIT
 * --------------------
 * UPPERLIMIT limits how many the array should be.
 */
#define UPPERLIMIT 10000

void main ()
{
	int i,Fprev,Fcurr,Fnext;

	i = 0;
	Fprev = 0;
	Fcurr = 1;
	Fnext = 0;

	printf("This program lists the Fibonacci sequence.\n\n");
	for (;Fnext <= UPPERLIMIT;i++)
	{
		printf("  F( %-3d)  =%6d\n\n",i,Fnext);
		Fprev = Fcurr;
		Fcurr = Fnext;
		Fnext = Fprev + Fcurr;
	}
}