/*
 * File: ex0406.c
 * --------------
 * Simulates a coundown for a rocket launch.
 */
#include <stdio.h>

/*
 * Constant STARTINGCOUNT
 * ----------------------
 * Change file constant to use a different starting value.
 */
#define STARTINGCOUNT 10

void main()
{
	int t;

	t = STARTINGCOUNT;

	while (t)
	{
		printf(" %d \n",t);
		t--;
	}
}

