/*
 * File: ex0407.c
 * --------------
 * This program reverses an integer input from user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

void main ()
{
	int N,nDigit;

	N = 0;
	nDigit = 0;

	printf("Program to reverse an integer.\n");
	printf("Input an integer ");
	N = GetInteger();
	printf(" The reverse number is ");
	while (N)
	{
		nDigit = (N % 10);
		printf("%d",nDigit);
		N /= 10;
	}
}