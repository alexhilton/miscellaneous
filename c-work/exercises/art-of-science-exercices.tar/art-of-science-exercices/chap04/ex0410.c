/*
 * File: ex0410.c
 * --------------
 * Display an triangular on terminal with '*' like:
 *    |*
 *	  |* *
 *    |* * *
 *    |* * * *
 * and so forth.
 */
#include <stdio.h>

/*
 * constant: UPPERLIMIT
 * --------------------
 * The biggest lines.
 */
#define UPPERLIMIT 8

void main()
{
	int i, j;

	i = 1;
	j = 1;

	printf("This program displays an '*' triangular.\n\n");

	for (i = 1;i <= UPPERLIMIT;i++)
	{
		for (j = 1;j <= i;j++)
		{
			printf("* ");
		}
		printf("\n\n");
	}
}