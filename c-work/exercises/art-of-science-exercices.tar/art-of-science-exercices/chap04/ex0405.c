/*
 * File: ex0405.c
 * --------------
 * The program finds all the number between 1 and 100 which are divisible
 * by 6 or 7 but not both.
 */
#include <stdio.h>

#include "genlib.c"
/*
 * Constants: LOWERLIMIT,MAXLIMIT,DIVISOR1,DIVISOR2
 * -------- --------- ---------- --------- ---------
 * LOWERLIMIT and MAXLIMIT are the lower and upper limits of integers.
 * while DIVISOR1 and DIVISOR2 are the integers which will be divided.
 */
#define LOWERLIMIT 1
#define UPPERLIMIT 100
#define DIVISOR1 6
#define DIVISOR2 7

void main ()
{
	int i;
	bool p, q;

	i = LOWERLIMIT;
	p = q = TRUE;

	printf("Program to find all numbers between \n");
	printf(" [%d , %d]",LOWERLIMIT,UPPERLIMIT);
	printf(" by %d or %d,but not both.\n",DIVISOR1,DIVISOR2);

	for (;i <= UPPERLIMIT;i++)
	{
		p = ((i % 6) == 0);
		q = ((i % 7) == 0);
		if ((p && !q) || (!p && q))
		{
			printf("   %d\n",i);
		}
	}
}