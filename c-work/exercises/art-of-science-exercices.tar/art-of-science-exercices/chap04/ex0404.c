/*
 * File: ex0404.c
 * --------------
 * The program finds all the number between 1 and 100 which are divisible
 * by either 6 or 7.
 */
#include <stdio.h>

/*
 * Constants: LOWERLIMIT,MAXLIMIT,DIVISOR1,DIVISOR2
 * -------- --------- ---------- --------- ---------
 * LOWERLIMIT and MAXLIMIT are the lower and upper limits of integers.
 * while DIVISOR1 and DIVISOR2 are the integers which will be divided.
 */
#define LOWERLIMIT 1
#define UPPERLIMIT 100
#define DIVISOR1 6
#define DIVISOR2 7

void main ()
{
	int i;

	i = LOWERLIMIT;

	printf("Program to find all numbers between \n");
	printf(" [%d , %d]",LOWERLIMIT,UPPERLIMIT);
	printf(" by %d and %d .\n",DIVISOR1,DIVISOR2);

	for (;i <= UPPERLIMIT;i++)
	{
		if ((i % 6) == 0 || (i % 7) == 0)
		{
			printf("   %d\n",i);
		}
	}
}