/*
 * File: ex0411.c
 * --------------
 * Display an triangular on terminal with '*' like:
 *    |   *
 *	  |  * *
 *    | * * *
 *    |* * * *
 * and so forth.
 */
#include <stdio.h>

/*
 * constant: UPPERLIMIT
 * --------------------
 * The biggest lines.
 */
#define UPPERLIMIT 8

void main()
{
	int i, j,nBound;   /* nBound is the Bound of space and the '*' */

	i = 1;
	j = 1;
	nBound = 0;

	printf("This program displays an '*' triangular.\n\n");

	for (i = 1;i <= UPPERLIMIT;i++)
	{
		nBound = UPPERLIMIT - i;
		for(j = 0;j < nBound;j++)
		{
			printf(" ");
		}
		nBound = 2 * i - 1;
		for (j = 1;j <= nBound;j++)
		{
			printf("*");
		}
		printf("\n\n");
	}
}