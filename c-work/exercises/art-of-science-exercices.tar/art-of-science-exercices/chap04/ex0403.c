/*
 * File: ex0403.c
 * --------------
 * Program to sum the first N odd integers, which input from user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

void main ()
{
	/* Variables declaration blcok */
	int nOdd,nSum,N,i;

	/* Variables initializing. */
	nOdd = 1;
	nSum = 0;
	i = 0;

	/* syntax blcok */
	printf("program to sum first N numbers.\n");
	printf("How many do you want to sum ");
	N = GetInteger();
	for (;i < N;i++)
	{
		nSum += nOdd;
		nOdd += 2;
	}
	printf("The sum of first %d integers are %d\n",N,nSum);
}