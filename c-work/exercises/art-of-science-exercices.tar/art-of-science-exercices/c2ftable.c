/*
 * file: ex0503.c
 * --------------
 * This program generates a table of converting from Fahrenheit
 * to Celsius.
 */
#include <stdio.h>

/*
 * Constants: LOWERLIMIT,UPPERLIMIT,STEPSIZE.
 * --------- ----------- ---------- ----------
 * LOWERLIMIT -- starting value for converting
 * UPPERLIMIT -- final value for converting
 * STEPSIZE   -- step size between table entries.
 */
#define LOWERLIMIT 32
#define UPPERLIMIT 100
#define STEPSIZE 2

/* Function Prototypes */
double FahrenheitToCelsius(int f);

/*  Main Program */
void main ()
{
	int f;

	f = 0;

	printf("Fahrenheit to Celsius table.\n\n");
	printf("  F       C\n\n");
	for (f = LOWERLIMIT;f <= UPPERLIMIT;f += STEPSIZE)
	{
		printf("%5d       %4.1f\n",f,FahrenheitToCelsius(f));
	}
}

/*
 * Function: FahrenheitToCelsius
 * Usage: c = FahrenheitToCelsius(f);
 * -----------------------------------
 * This function returns the Celsius equivalent of the Fahrenheit
 * temperature f.
 */
double FahrenheitToCelsius(int f)
{
	return (5.0 * (f - 32) / 9.0);
}

