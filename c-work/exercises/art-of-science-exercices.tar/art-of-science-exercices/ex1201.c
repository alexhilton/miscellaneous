/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * description
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>

/* constant: BASE -- the base of computing decimal 10 */
#define BASE 10

/* type enumeration: color_t */
typedef enum { BLACK, BROWN, RED, ORANGE, YELLOW,
  GREEN, BLUE, VIOLET, GRAY, WHITE } color_t;

/* main program */
int main( int argc, char **argv )
{
  color_t stband;	/* first band */
  color_t ndband;	/* second band */
  color_t rdband;	/* third band */
  int power;
  int digits;
  int r;		/* resistance */
  char *band;

  band = ( char * ) malloc( 10 );
  printf( "\n Enter first band: ");
  scanf( "%d", band ); 
  stband = ( color_t ) band;
  printf( "\n Enter second band: ");
  scanf( "%d", band ); 
  ndband = ( color_t ) band;
  printf( "\n Enter third band: ");
  scanf( "%d", band ); 
  rdband = ( color_t ) band;
  power = pow( BASE, rdband );
  digits = BASE * stband + ndband;
  r = digits * power;
  printf( "\n%d\n", r );

  return ( 0 );
}
/* End $Source$ */
