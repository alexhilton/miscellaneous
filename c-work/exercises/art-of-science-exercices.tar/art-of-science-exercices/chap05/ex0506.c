/*
 * File: ex0506.c
 * --------------             k
 * Tis program caculate the  X , x is a floating-point but
 * k is  an integer,which either negetive or positive.
 *						     		   k
 * Then display a table of values of 10  for all values
 * from -4 to 4.
 */
#include <stdio.h>
#include <math.h>

/*
 * Constant: N,LOWERLIMIT,UPPERLIMIT
 * --------- ----------- ------------
 * N -- is the basement of power caculation;
 * LOWERLIMIT -- is the start value of power;
 * UPPERLIMIT -- is the max value of power.
 */
 #define BASE 10
 #define LOWERLIMIT -4
 #define UPPERLIMIT 4

 /* Function prototype */
 double RaiseRealToPower(double base,int k);

 /* main function */
 main ()
 {
	int k;

	k = 0;

	printf("this program makes a table of value power:\n\n");
	printf("                     k\n");
	printf("      fk		  %d\n",BASE);
	printf("  ----------------------\n\n");
	for (k = LOWERLIMIT;k < 0;k++)
	{
		printf("     %2d          %g\n\n",k,RaiseRealToPower(BASE,k));
	}
	for (k = 0;k <= UPPERLIMIT;k++)
	{
		printf("     %2d      %7.1f\n\n",k,RaiseRealToPower(BASE,k));
	}
 }

/*
 * Function: RaiseRealToPower
 * Usage: i = RaiseRealToPower(base,k);
 * ---------------------------------
 * this function returns the power k of value base.
 * x is a floating-point number, while k is an integer
 * which can be either negetive or positive.
 */
double RaiseRealToPower(double base,int k)
{
	int i,nAbsk; /* nAbsk is the absolute value of k */
	double dResult;

	i = 0;
	dResult = 1;
	nAbsk = abs(k);

	if (k == 0)
	{
		return (1);
	}
	for (i = 0;i < nAbsk;i++)
	{
		dResult *= base;
	}
	if (k < 0)
	{
		dResult = 1.0 / dResult;
	}
	return (dResult);
}


