/*
 * File: ex0508.c
 * --------------
 * This program to test three functions:
 * Round, Ceiling,Floor which parameters are all float-point.
 * Round returns the nearest integer of x.
 * Ceiling returns the integer greater than x.
 * Floor returns the integer less than x.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constant: CARRY
 * ----------------
 * CARRY -- is used to truncate the float number.
 */
#define CARRY 0.5

/* function prototype */
int Round(double x);
int Ceiling(double x);
int Floor(double x);

/* main program */
main()
{
	double x;

	x = 0;

	printf(" floating-point number rounding program\n");
	printf("Input number ");
	x = GetReal();
	printf(" Round is   %d\n\n",Round(x));
	printf(" Ceiling is %d\n\n",Ceiling(x));
	printf(" Floor is   %d\n\n",Floor(x));
}

/*
 * Function: Round
 * Usage: n = Round(x);
 * ---------------------
 * This function returns the nearest integer of floating-point
 * x.
 */
int Round(double x)
{
	int nResult;

	nResult = 0;

	if (x < 0)
	{
		nResult = (int) (x - CARRY);
	}
	else
	{
		nResult = (int) (x + CARRY);
	}
	return (nResult);
}

/*
 * Function: Ceiling
 * Usage: k = Ceiling(x);
 * -----------------------
 * This function returns the integer greater than x, which is a
 * floating-point nunber.
 */
int Ceiling(double x)
{
	return ((int) (x + 1.0));
}

/*
 * Function: Floor
 * Usage: k = Floor(x);
 * --------------------
 * This function returns the integer less than floating-point x.
 */
int Floor(double x)
{
	return ((int) x);
}