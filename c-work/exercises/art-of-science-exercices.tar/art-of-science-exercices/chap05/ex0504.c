/*
 * file: ex0504.c
 * --------------
 * This program to caculate Fibonacci array with a function.
 */
#include <stdio.h>

/*
 * Constant: UPPERLIMIT
 * --------------------
 * the number will be displayed.
 */
#define UPPERLIMIT 15

/* function prototype */
int Fibonacci(int n);

/* main program */
void main ()
{
	int i;

	i = 0;

	printf("Fibonacci array, first %d items\n\n",UPPERLIMIT);

	for (i = 0;i <= UPPERLIMIT;i++)
	{
		printf(" F( %-3d)  =%5d\n\n",i,Fibonacci(i));
	}
}

/*
 * function: Fibonacci
 * usage: n = Fibonacci(i);
 * ------------------------
 * This function returns the ith item of Fibonacci array.
 */
int Fibonacci(int n)
{
	int i,Fprev,Fnext,Fcurr;

	i = 0;
	Fprev = 0;
	Fcurr = 1;
	Fnext = 0;

	for (i = 0;i < n;i++)
	{
		Fprev = Fcurr;
		Fcurr = Fnext;
		Fnext = Fcurr + Fprev;
	}
	return (Fnext);
}