/*
 * File: ex0502.c
 * --------------
 * this program roots a quardratic equation.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "simpio.c"

void main ()
{
	double a,b,c,root1,root2,d;

	a = b = c = 0;
	root1 = root2 = d = 0;

	printf("This program roots a quadratic equation.\n");
	printf("  a: ");
	a = GetReal();
	printf("  b: ");
	b = GetReal();
	printf("  c: ");
	c = GetReal();

	if (a == 0)
	{
		Error("This is not a quadratic equation.");
	}
	else
	{
		d = (b * b - 4 * a * c);
		if (d < 0)
		{
			Error("No real roots existing.");
		}
		else
		{
			root1 = (-b + sqrt(d)) / (2 * a);
			root2 = (-b - sqrt(d)) / (2 * a);
			printf("The first root is %g\n",root1);
			printf("The second roots is %g \n",root2);
		}
	}
}

