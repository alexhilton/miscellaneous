/*
 * File: ex0507.c
 * --------------
 * This program dispaly the number of digits in an integer
 * by calling a function: NDigits.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/* Function prototype */
int NDigits(int n);

/* main program */
main()
{
	int nValue;

	nValue = 0;

	printf("Program to make Number of digits in an integer\n");
	printf("Input a integer ");
	nValue = GetInteger();
	printf("The number of digits in %d is %d\n",nValue, NDigits(nValue));
}

/*
 * Function: NDigits()
 * Usage: k = NDigits(n);
 * ----------------------
 * this function returns the number of digits in n.
 */
int NDigits(int n)
{
	int nCNT;

	nCNT = 0;

	while (n)
	{
		n /= 10;
		nCNT++;
	}
	return (nCNT);
}