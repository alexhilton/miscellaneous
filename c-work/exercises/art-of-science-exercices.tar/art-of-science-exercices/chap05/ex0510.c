/*
 * File: ex0510.c
 * --------------
 * This program can solve the issues arouse when compare two
 * floating-point numbers. The function ApproximatelyEqual(x,y)
 * can determine whether the two floating-point x,y are
 * approximately equivalent.You can reset the Epsilon to
 * determine the precision to meet your need.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"

/*
 * Constant: EPSILON
 * -----------------
 * EPSILON -- is the accuracy control handle.
 */
#define EPSILON 0.000001

/* function prototype */
bool ApproximatelyEqual(double x,double y);

/* main program */
main()
{
	double x;

	printf(" display from 1.0 to 2.0 with step 0.1\n");
	for (x = 1.0;x > 0.1;x += 0.1)
	{
		printf(" %3.1f\n",x);
		if (ApproximatelyEqual(x,2.0)) break;
	}
}

/*
 * Function: ApproximatelyEqual()
 * Usage: if (ApproximatelyEqual(x,y)) ...
 * ----------------------------------------
 * the two argument are approximately equal, if
 * the absolute value of the difference between the
 * two numbers divided by the smaller of their absolute vlues is
 * less than some constant EPSILON.
 * that can be described in Mathematical way:
 *
 *     |x - y|
 * --------------- < EPSILON
 *   min(|x|,|y|)
 *
 * the EPSILON can be reset to meet any accuracy.
 */
bool ApproximatelyEqual(double x,double y)
{
	/* dist -- is the distance between x,y or |x-y| in Math*/
	/* dmin -- is the less of the absolute value of the two argements */
	double dist,dmin;

	dist = fabs(x - y);
	dmin = fabs(x);

	if (fabs(x) > fabs(y))
	{
		dmin = fabs(y);
	}
	return ((dist / dmin) < EPSILON);
}