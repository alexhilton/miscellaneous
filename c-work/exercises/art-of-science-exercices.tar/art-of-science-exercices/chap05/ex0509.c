/*
 * File: ex0509.c
 * --------------
 * This program to test the function: IsPerfectSquare
 * which tests whether a number is a perfect square.
 */
#include <stdio.h>
#include <math.h>

#include "genlib.c"
#include "simpio.c"

/* function prototype */
bool IsPerfectSquare(int n);

/* main program */
main ()
{
	int nValue;

	nValue = 0;

	printf(" perfect squqre testing program\n");
	printf(" Input an integer ");
	nValue = GetInteger();
	if (IsPerfectSquare(nValue))
	{
		printf(" %d is a perfect square number\n",nValue);
	}
	else
	{
		printf(" %d is not a perfect square number\n",nValue);
	}
}

/*
 * Function: IsPerfectSquare
 * Usage: if (IsPerfectSquare(n)) ...
 * -----------------------------------
 * This function tests whether an integer is a perfect square number.
 * For example, integer 4 is one, because its root 2, 2*2 = 4.
 * While 5 is not, because its root, 2.632 * 2.632 != 5.
 */
bool IsPerfectSquare(int n)
{
	double dRoot;

	dRoot = sqrt(n);

	return ((dRoot * dRoot) == n);
}
