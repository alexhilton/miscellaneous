/*
 * File: calendar.c
 * -----------------
 * This program is used to generate a calendar for a year entered
 * by the user.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"

/*
 * Constants:
 * ----------
 * Days of the week are represented by the integers 0~6
 * Months of the year are identified by the integers 1~12
 * because this numeric representation for months is in
 * common use, no special constants are defined.
 */
#define SUNDAY 0
#define MONDAY 1
#define TUESDAY 2
#define WEDNESDAY 3
#define THURSDAY 4
#define FRIDAY 5
#define SATURDAY 6

/* function prototypes */
void GiveInstruction(void);
int GetYearFromUser(void);
void PrintCalendar(int year);
void PrintCalendarMonth(int month,int year);
void IndentFirstLine(int weekday);
int MonthDay(int month,int year);
int FirstDayOfMonth(int month,int year);
string MonthName(int month);
bool IsLeapYear(int year);

/* Main Program */
main ()
{
	int year;

	GiveInstruction();
	year = GetYearFromUser();
	PrintCalendar(year);
}

/*
 * Function: GiveInstruction
 * Usage: GiveInstruction();
 * -------------------------
 * this procedure prints out instruct to the user.
 */
void GiveInstruction(void)
{
	printf("\n This program displays a calendar fro a full\n");
	printf(" year. The year must not be before 1900.\n");
	printf(" you can enter the last two instead of four,\n");
	printf(" when enter a year.\n");
}

/*
 * Function: GetYearFromUser
 * Usage: year = GetYearFromUser();
 * --------------------------------
 * this function reads in a year from the user and returs
 * that value. If the user enters a year before 1900, the
 * function gives the user anohter chance.
 */
int GetYearFromUser(void)
{
	int year;
	while(TRUE)
	{
		printf(" Which year? ");
		year = GetInteger();
		if (year < 100 && year > 0)
		{
			return (1900 + year);
		}
		else if (year >= 1900)
		{
			return (year);
		}
		else
		{
			printf(" The year must be at least 1900.\n");
		}
	}
}

/*
 * Function: PrintCalendar
 * Usage; PrintCalendar();
 * ------------------------
 * This function prints a calendar for an entire year.
 */
void PrintCalendar(int year)
{
	int month;

	for (month = 1;month < 13;month++)
	{
		PrintCalendarMonth(month,year);
		printf("\n");
	}
}

/*
 * Function: PrintCalendarMonth
 * Usage: PrintCalendarMonth(month,year);
 * --------------------------------------
 * This procedure prints a calendar for the given month.
 */
void PrintCalendarMonth(int month,int year)
{
	int weekday,nDays,day;

	printf("\n   %s  %d\n",MonthName(month),year);
	printf("\n Sun Mon Tue Wed Tur Fri Sat\n\n");
	nDays = MonthDay(month,year);
	weekday = FirstDayOfMonth(month,year);
	IndentFirstLine(weekday);
	for (day = 1;day <= nDays;day++)
	{
		printf(" %3d",day);
		if (weekday == SATURDAY)
		{
			printf("\n\n");
		}
		weekday = (weekday + 1) % 7;
	}
	if (weekday != SUNDAY)
	{
		printf("\n\n");
	}
}

/*
 * Function: IndentFirstLine
 * Usage: IndentFirstLine(weekday);
 * --------------------------------
 * this procedure indents the first line of the calendar
 * by printing enough blank spaces to get to the position
 * on the line corresponding to weekday.
 */
void IndentFirstLine(int weekday)
{
	int i;

	for (i = 0;i < weekday;i++)
	{
		printf("    ");
	}
}

/*
 * Function: MonthDay
 * Usage: ndays = MonthDay(month,year);
 * ------------------------------------
 * MonthDay returns the number of days in the indicated
 * month and year. The year is required to handle leap years.
 */
int MonthDay(int month,int year)
{
	switch (month)
	{
		case 2:
		{
			if (IsLeapYear(year))
			{
				return (29);
			}
			return (28);
		}
		case 4: case 6: case 9: case 11:
		{
			return (30);
		}
		default:
		{
			return (31);
		}
	}
}

/*
 * Function: FirstDayOfMonth
 * Usage: weekday = firstDayOfMonth(month,year);
 * ---------------------------------------------
 * this function returns the day of the week on which the
 * indicated from January 1st,1900, which was a Monday.
 */
int FirstDayOfMonth(int month,int year)
{
	int weekday,i;

	weekday = MONDAY;
	for (i = 1900;i < year;i++)
	{
		weekday = (weekday + 365) % 7;
		if (IsLeapYear(i))
		{
			weekday = (weekday + 1) % 7;
		}
	}
	for (i = 1;i < month;i++)
	{
		weekday = (weekday + MonthDay(i,year)) % 7;
	}
	return (weekday);
}

/*
 * Function: MonthName
 * Usage: name = MonthName(month);
 * -------------------------------
 * MonthName converts a numeric month in the range 1~12
 * into the string name for that month.
 */
string MonthName(int month)
{
	switch (month)
	{
	  case 1:
	  {
		return ("January");
	  }
	  case 2:
	  {
		return ("February");
	  }
	  case 3:
	  {
		return ("March");
	  }
	  case 4:
	  {
		return ("April");
	  }
	  case 5:
	  {
		return ("May");
	  }
	  case 6:
	  {
		return ("June");
	  }
	  case 7:
	  {
		return ("July");
	  }
	  case 8:
	  {
		return ("August");
	  }
	  case 9:
	  {
		return ("September");
	  }
	  case 10:
	  {
		return ("October");
	  }
	  case 11:
	  {
		return ("November");
	  }
	  case 12:
	  {
		return ("December");
	  }
	}
}

/*
 * Function: IsLeapYear
 * Usage: if (IsLeapYear(year)) ...
 * ---------------------------------
 * This function returns TRUE if year is a leap year.
 */
bool IsLeapYear(int year)
{
	return ( ((year % 4 == 0) && (year % 100 != 0))
		|| (year % 400 == 0) );
}