/*
 * File: ex0511.c
 * --------------
 * This is a general program appearing in kinds of games, which
 * responses to user's input after giving instructions first.
 */
#include <stdio.h>

#include "genlib.c"
#include "simpio.c"
#include "strlib.c"

/* Function prototypes */
void PlayOneGame(void);
bool GetYesOrNo(string s);

/* main program */
main ()
{
	while(TRUE)
	{
		PlayOneGame();
		if (!GetYesOrNo(" Would you like to play again?")) break;
	}
}

/*
 * Function: PlayOneGame()
 * Usage: PlayOneGame();
 * ------- ------ ---------
 * This program lets the user play a game once.
 * Here, it just displays a string " ...play the game...".
 */
void PlayOneGame(void)
{
	printf("   ...play the game...\n");
}

/*
 * function: GetYesOrNo
 * Usage: if (GetYesOrNo(str)) ...
 * ------ ------ ------- ----------
 * This function asks the user whether to play again.
 * If the user input yes, then return TRUE.
 * if the user input no, then return FALSE
 * if the user input anthing else, give error msg and wait for
 * another inputing.
 */
bool GetYesOrNo(string str)
{
	string response;

	response = NULL;

	while(TRUE)
	{
		printf("%s ",str);
		response = GetLine();
		if (StringEqual(response,"yes"))
		{
			return (TRUE);
		}
		else if(StringEqual(response,"no"))
		{
			return (FALSE);
		}
		else
		{
			printf(" Please answer yes or no.\n");
		}
	}
}


