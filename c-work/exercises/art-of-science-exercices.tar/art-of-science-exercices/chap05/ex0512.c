/*
 * File: ex0512.c
 * --------------
 * This program will generate the Pascal's Triangular like:
 * 						1
 *					  1   1
 *				   1   2  2  1
 * 				.................
 * the Marco LINE is the lines will generate which can changed.
 */
#include <stdio.h>
#include "genlib.c"

/*
 * Constant: LINE
 * --------------
 * LINE -- is the lines of the triangular displayed.
 */
#define LINE 8

/* Function prototypes */
int Factoral(int n);
int Combainations(int m,int n);
void GiveInstruction(void);
void PascalTrian(int n);

/* main program */
main()
{
	GiveInstruction();
	PascalTrian(LINE);
}

/*
 * Function: PascalTrian
 * Usage: PascalTrian(n);
 * ----------------------
 * This function will generate a Pascal's Triangular like:
 * 				1
 * 		    1       1
 *      1    2    2    1
 *   ......................
 */
void PascalTrian(int n)
{
	int nBound,i,j; /* nBound is the bound of triangular and space */

	i = 0;
	nBound = 0;
	j = 0;

	for (i = 0;i < n;i++)
	{
		nBound = n - i;
		for (j = 0;j < nBound - 1;j++)
		{
			printf("  ");
		}
		for (j = 0;j <= i;j++)
		{
			printf("%2d  ",Combination(i,j));
		}
		printf("\n\n");
	}
}

/*
 * Function: Combination
 * Usage: k = Combination(m,n);
 * ----------------------------
 * This function returns the comhination of two integers.
 */
int Combination(int m,int n)
{
	int temp;

	if (m < n)
	{
		temp = m;
		m = n;
		n = temp;
	}
	return (Factoral(m) / (Factoral(n) * Factoral(m - n)));
}

/*
 * Function: Factoral
 * Usage: n = Factoral(k);
 * -----------------------
 * The function returns the factoral of integer k.
 */
int Factoral(int n)
{
	int product,i;

	product = 1;

	if (n < 1) return (product);
	for (i = 1;i <= n;i++)
	{
		product *=i;
	}
	return (product);
}

/*
 * Functon: GiveInstruct
 * Usage: GiveInstruct();
 * ----------------------
 * This function gives the user some information about the
 * program, also gives some instructions and restrictions.
 */
void GiveInstruction(void)
{
	printf(" This program will generate a Pascal's Triangular\n");
	printf(" which is %d lines.\n\n",LINE);
}