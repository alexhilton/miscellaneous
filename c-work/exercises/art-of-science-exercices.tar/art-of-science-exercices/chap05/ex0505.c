/*
 * File: ex0505.c
 * --------------                    k
 * This program caculates the power n , which n and k are both
 * integers.                     k
 * The program makes a table of 2  for all values of
 * k from 0 to 10.
 */
#include <stdio.h>

/*
 * Constant: N,UPPERLIMIT, LOWERLIMIT
 * -----------------------------------
 * N -- the value of bottom value.
 * UPPERLIMIT -- the upper limit of power.
 * LOWERLIMIT -- the start value of power.
 */
#define BASE 2
#define UPPERLIMIT 10
#define LOWERLIMIT  0

/* Function prototype */
int RaiseIntToPower(int base,int k);

/* mai program */
void main ()
{
	int i;

	i = 0;

	printf("Table of %d power.\n\n",BASE);
	for (i = LOWERLIMIT;i <= UPPERLIMIT;i++)
	{
		printf("i = %-3d --- %6d\n\n",i,RaiseIntToPower(BASE,i));
	}
}

/*
 * Function: RaiseIntToPower
 * Usage: n = RaiseIntToPower(base,k);
 * ----------------------------------- k
 * this function returns the power base .
 */
int RaiseIntToPower(int base,int k)
{
	int i,nResult;

	i = 0;
	nResult = 1;
	if (k == 0) return (1);
	for (i = 0;i < k;i++)
	{
		nResult *=base;
	}
	return (nResult);
}
