/*
 * File: ex0501.c
 * -------- --------
 * Caculate the Golden Ratio.
 */
#include <stdio.h>
#include <math.h>

void main ()
{
	double dGoldenRatio;

	dGoldenRatio = 0;

	dGoldenRatio = (1 + sqrt(5)) / 2.0;
	printf("The GoldenRatio is %g\n",dGoldenRatio);
}