/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * implemnettation of interface str_ext.h
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";
#include <stdlib.h>
#include <stdio.h>


int str2int(
  char *str
) {
  int result;
  char dumy;

  if ( str == NULL ) {
    printf( "Error: no Input\n" );
    exit( EXIT_FAILURE );
  } 
  if ( ( sscanf( str, " %d %c", &result, &dumy ) != 1 ) ) {
    printf( "Error: %s", str );
    exit( EXIT_FAILURE );
  }
  return ( result );
}

/* End $Source$ */
