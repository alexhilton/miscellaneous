/*
 * $Header$
 *
 * Hitlion.Warrior.King					$Date$
 *
 * Revision History
 * $Log$
 */

#ifndef _myfile_h
#define _myfile_h  "@(#)myfile.h $Revision$"

#endif /* myfile.h */

/* End $Source$ */
