/*
 * $Header: /root/c-work/art_ex/chap10/scanner.c,v 1.3 2007/12/26 12:10:48 root Exp root $
 *
 * Hitlion.Warrior.King				$Date: 2007/12/26 12:10:48 $
 *
 * this file implements scanner.h interface.
 *
 * Revision History
 * $Log: scanner.c,v $
 * Revision 1.3  2007/12/26 12:10:48  root
 * enhance the ability, it can treat spaces as a token now.
 *
 * Revision 1.2  2007/12/12 17:57:30  root
 * fix a bug.
 *
 * Revision 1.1  2007/12/10 19:40:26  root
 * Initial revision
 *
 */
static const char rcsid[] = "$Id: scanner.c,v 1.3 2007/12/26 12:10:48 root Exp root $";

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>

#include "scanner.h"

static char *buffer;		/* private copy of string passed in */
static int buflen;		/* length of buffer */
static int cpos;		/* current character position */

void init_scanner(
  char *line
) {
  buffer = line;
  buflen = strlen( buffer );
  cpos = 0;
}


char *get_next_token(
  void
) {
  char ch;
  int start = 0;

  if ( cpos >= buflen ) {
    error( "No more tokens" );
  }
  ch = buffer[ cpos ];
  if ( isalnum( ch ) ) {
    start = cpos;
    while ( cpos < buflen && isalnum( buffer[ cpos ] ) ) {
      cpos++;
    }
     return ( substr( buffer, start, cpos - 1 ) );
  } else if ( isspace( ch ) ) {
    start = cpos;
    while ( cpos < buflen && isspace( buffer[ cpos ] ) ) {
      cpos++;
    }
    return ( substr( buffer, start, cpos - 1 ) );
  } else {
    cpos++;
    return ( char2str( ch ) );
  }
}

int at_end(
  void
) {
  return ( cpos >= buflen );
}


char *substr(
  char *str,
  int start,
  int end
) {
  int len;
  char *result;

  if ( str == NULL ) {
    error( "NULL string passed to substr" );
  }
  len = strlen( str );
  if ( start < 0 ) {
    start = 0;
  }
  if ( end >= len ) {
    end = len - 1;
  }
  len = end - start + 1;
  if ( len < 0 ) {
    len = 0;
  }
  result = ( char * ) malloc( len + 1 );
  strncpy( result, str + start, len );
  result[ len ] = '\0';

  return ( result );
}


void error(
  char *msg,
  ...
) {
  va_list args;

  va_start( args, msg );
  fprintf( stderr, " Error: " );
  vfprintf( stderr, msg, args );
  fprintf( stderr, "\n" );
  va_end( args );

  exit( EXIT_FAILURE );
}


char *char2str(
  char ch
) {
  char *result;

  result = ( char * ) malloc( 2 );
  result[ 0 ] = ch;
  result[ 1 ] = '\0';

  return ( result );
}


int is_legal_word(
  char *word
) {
  char *p = word;

  for( ; *p; p++ ) {
    if ( !isalnum( *p ) ) {
      return ( 0 );
    }
  }

  return ( 1 );
}

int is_vowel(
  char ch
) {
  char lower;

  lower = tolower( ch );
  switch ( lower ) {
    case 'a': case 'e': case 'i': case 'o': case 'u':
      return ( 1 );
    default:
      break;
  }

  return ( 0 );
}

int find_first_vowel(
  char *line
) {
  char *ch = line;

  for ( ; *ch; ch++ ) {
    if ( is_vowel( *ch ) ) {
      return ( ch - line );
    }
  }

  return ( -1 );
}


int is_space(
  char *token
) {
  char *p;

  p = token;
  for ( ; *p; p++ ) {
    if ( !isspace( *p ) ) {
      return ( 0 );
    }
  }

  return ( 1 );
}


char *get_upper_token(
  void 
) {
  char *token;
  char *p;
  if ( cpos >= buflen ) {
    error( "No more tokens" );
  }
  token = get_next_token();
  if ( is_legal_word( token ) ) {
    p = token;
    for ( ; *p; p++ ) {
      *p = toupper( *p );
    }
  }

  return ( token );
} 
