/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * exercise eleven of chap four.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Private function prototype(s) */
static int find_in_array(
  int key,
  char *str,
  int n
);

/* Main program */
int main( int argc, char **argv ) {
  return ( 0 );
}
/* End $Source$ */
