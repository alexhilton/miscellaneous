/*
 * $Header: /root/c-work/art_ex/chap10/scanner.h,v 1.2 2007/12/12 17:58:02 root Exp root $
 *
 * Hitlion.Warrior.King				$Date: 2007/12/12 17:58:02 $
 *
 * this file is the interface to a package that divides a line
 * into individual "token". A token is defined to be either.
 *
 * Revision History
 * $Log: scanner.h,v $
 * Revision 1.2  2007/12/12 17:58:02  root
 * fix a bug
 *
 * Revision 1.1  2007/12/10 19:40:10  root
 * Initial revision
 *
 */

#ifndef _scanner_h
#define _scanner_h

/*
 * Function: init_scanner
 * usage: init_scanner( str );
 *
 * This function initializes the scanner interface providing sufficient
 * information to make functions work all right for its callers.
 */
void init_scanner( 
  char *line
);


/*
 * Function: get_next_token
 * Usage: token = get_next_token();
 *
 * this function returns next token in the string whhich has been
 * passed to interface.
 * Note: you don't need to allocate space for token, because the 
 *	 spaces allocates in this interface.
 */ 
char *get_next_token(
  void
);

/*
 * Function: at_end
 * Usage: if ( at_end() ) ...
 *
 * this function returns true ( 1 ), if the cpos has reached the end of
 * buffer.
 */
int at_end(
  void
);


/*
 * Function: error
 * Usage: error( "msg", ... );
 *
 * This function provides a simple error handling. It generates
 * an error string, expanding % constructions appearing in the
 * error message, the program terminates.
 */
void error(
  char *msg,
  ...
);

/*
 * Function: substr
 * Usage: sub_str = substr( str, start, end );
 *
 * This function returns a sub string in str from position start to end.
 * For example, substr( "hello", 1, 4 ) should return "ello" to its caller.
 */
char *substr(
  char *buffer,
  int start,
  int end
);

/*
 * Function: char2str
 * Usage: str = char2str( ch );
 *
 * This function returns a string containing char ch.
 */ 
char *char2str(
  char ch
);

/*
 * Function: is_legal_word
 * Usage: if ( is_legal_word( word ) ...
 *
 * this function will return true ( 1 ), if word only consists of 
 * english letter and Abric digits.
 */
int is_legal_word(
  char *word
);

/*
 * Function: find_first_vowel
 * Usage: index = find_first_vowel( word );
 *
 * This function returns the index of first vowel appearing in word.
 * For example, find_first_vowel( "hello" ) shold return 1. ( NOTE:
 * that this function returns the index, because the array in C are
 * always start from 0. So the index would be one less than our sense.
 */ 
int find_first_vowel(
  char *line
);

/*
 * Function: is_vowel
 * Usage: if ( is_vowel( ch ) ) ..
 *
 * This function returns true, if ch is a vowel in english.
 * It ignores the case, for example, both is_vowel( 'A' ) and
 * is_vowel( 'a' ) return true.
 */
int is_vowel(
  char ch
);


/*
 * function: is_space
 * Usage: if ( is_space( token ) ) ...
 *
 * This function returns true if token only consists spaces, tab, and 
 * all others that isspace function in ANSI lib returns true.
 */
int is_space(
  char *token
);


/*
 * Function: get_upper_token
 * Usage:  token = get_upper_token();
 *
 * This function returns an upper token.
 */
char *get_upper_token(
  void 
);
#endif /* scanner.h */

/* End of $Source: /root/c-work/art_ex/chap10/scanner.h,v $ */
