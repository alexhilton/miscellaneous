/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * example two of chap five.
 * implementation of permeratation.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

/* Private function prototype(s) */
static void list_perm(
  char *str
);
static void perm(
  char *str,
  int k
);
static void swap(
  char *str,
  int p1,
  int p2
);

/* Main program */
int main( int argc, char **argv ) {
  list_perm( "ABCDEF" );

  return ( 0 );
}

static void list_perm(
  char *str
) {
  perm( str, 0 );
}

static void perm(
  char *str,
  int k
) {
  int i;
  if ( k == strlen( str ) ) {
    printf( "%s\n", str );
  } else {
    for ( i = k; i < strlen( str ); i++ ) {
      swap( str, k, i );
      perm( str, k + 1 );
      swap( str, k, i );
    }
  }
}

static void swap(
  char *str,
  int p1,
  int p2
) {
  char tmp;
  tmp = str[ p1 ];
  str[ p1 ] = str[ p2 ];
  str[ p2 ] = tmp;
}
/* End $Source$ */
