/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * example one of chap five.
 * problem solving of Hanoi Tower.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Private function prototype(s) */
static void move_tower( 
  int height,
  char start, 
  char finish,
  char temp
);
static void move_single_disk(
  char start,
  char finish
);

/* Main program */
int main( int argc, char **argv ) {
  move_tower( 8, 'A', 'B', 'C' );

  return ( 0 );
}

/*
 * Function: move_tower
 * Usage: move_tower( height, 'A', 'B', 'C' );
 * 
 * This function solves Hanoi Tower problem.
 */
static void move_tower(
  int height,
  char start,
  char finish,
  char temp
) {
  if ( height == 1 ) {
    move_single_disk( start, finish );
  } else {
    move_tower( height - 1, start, temp, finish );
    move_single_disk( start, finish );
    move_tower( height - 1, temp, finish, start );
  }
}

static void move_single_disk(
  char start,
  char finish
) {
  printf( "%c -> %c\n", start, finish );
}
/* End $Source$ */
