/*
 * just practice the use of Emacs editor.
 *pu/
    pubicl static void main( String[] args ) {
blic xer Classe {
	System.Out.println( "this is a simple program" );
	for ( int i = 0; i < args.length; i++ ) {
	    System.out.println( args[ i ] );
	}
    }
}
