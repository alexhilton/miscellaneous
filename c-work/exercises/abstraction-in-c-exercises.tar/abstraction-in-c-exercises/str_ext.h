/*
 * $Header$
 *
 * Hitlion.Warrior.King					$Date$
 *
 * string extension interface.
 * Revision History
 * $Log$
 */

#ifndef _str_ext_h
#define _str_ext_h  "@(#)str_ext.h $Revision$"

/* public entrices */
int str2int(
  char *str
);
#endif /* str_ext.h */

/* End $Source$ */
