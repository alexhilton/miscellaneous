/*
 * test.c
 *
 * test input from arguments of main function.
 */
#include <stdio.h>
static int str2int(
  char *str
);

int main( int argc, char **argv ) {
  int i = 0;
  for ( i = 1; i < argc; i++ ) {
    printf( "%d\n", str2int( argv[ i ] ) ) ;
  }
  return ( 0 );
}
static int str2int(
  char *str
) {
  int result;
  char dumy;
  if ( str == NULL ) {
    printf( "Error: no input\n" );
  }
  if ( sscanf( str, " %d %c", &result, &dumy ) != 1 ) {
    printf( "error: %s", str );
  }
  return ( result );
}
