/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * description
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* private function prototypes */

/* main program */
int main( int argc, char **argv )

/* End $Source$ */
