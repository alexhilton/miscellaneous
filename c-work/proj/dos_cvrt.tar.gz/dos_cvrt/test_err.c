/*
 * $Header$
 *
 * Hitlion.Warrior.King				$Date$
 *
 * test special error.
 *
 * Revision History
 * $Log$
 */
static const char rcsid[] = "$Id$";

#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern int sys_nerr;

int main( int argc, char **argv )
{
  int x;
  static int ecodes[] = { -1, EIO, 0 };

  /* get maximum code */
  ecodes[ 2 ] = sys_nerr;

  for ( x = 0; x < 3; x++ ) {
    printf( "%4d = '%s'\n", ecodes[ x ], strerror( ecodes[ x ] ) );
  }

  return ( 0 );
}
/* End $Source$ */
