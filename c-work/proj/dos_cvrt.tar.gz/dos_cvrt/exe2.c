/*
 * doscvrt.c
 * $Header: /root/proj/convertor/doscvrt.c,v 1.5 2008/11/02 17:08:54 root Exp root $
 *
 * Build a tool that can convert MS-Dos text file into Unix format.
 * It assumes that the input file is ASCII text file. The output file
 * is ASCII text file in Unix format.
 * 
 * Author: Hitlion Warrior King
 *
 * Date: $Date: 2008/11/02 17:08:54 $
 *
 * Revision Log:
 * $Log: doscvrt.c,v $
 * Revision 1.5  2008/11/02 17:08:54  root
 * long options capable.
 *
 * Revision 1.4  2008/11/02 16:43:26  root
 * Options processing capable.
 * ,
 *
 * Revision 1.3  2008/11/01 23:50:49  root
 * Has been modularized.
 *
 * Revision 1.2  2008/10/31 23:01:38  root
 * Replace with function.
 *
 * Revision 1.1  2008/10/30 23:26:31  root
 * Initial revision
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>
#include "doscvrt.h"

/* RCS id */ 
static const char rcsid[] = "$Id: doscvrt.c,v 1.5 2008/11/02 17:08:54 root Exp root $";

extern char *optarg; /* Option argument */
extern int optind; /* option/arg index */
extern int opterr; /* error handling flag */

/*
 * show brief command usage help
 */
static void usage( const char *cmd ) {
  fprintf( stdout, "Usage: %s [-h | --help] [-u] [--version] infile..\n", cmd );
  fputs( "\t-h (or --help)\t\tGives this help display.\n", stdout );
  fputs( "\t--version\tDisplays program version.\n", stdout );
  fputs( "\t-u\t\tSpecifies UNIX to DOS conversion.\n\n", stdout );
  fputs( "Command unixcvrt converts UNIX to DOS text.\n", stdout );
  fputs( "while doscvrt converts DOS to UNIX text, except when -u option is used.\n\n", stdout );
}

static void filter( const char *cmd ) {
  fprintf( stdout, "filtering file %s\n", cmd );
}

/*
 * return the pionter to the basename component of a pathname
 */
static char *basename( const char *path ) {
  char *base_name = NULL;

  base_name = strrchr( path, '/' );
  if ( base_name != NULL ) {
    base_name++; /* skip over */
  } else {
    base_name = (char *) path; /* No dir. component */
  }
  return base_name;
}

int main( int argc, char *argv[] ) {
  char *base_name = NULL; /* basename of command */
  int rc = 0; /* command return code */
  int (*conv)( const char *pathname ); /* Conv. Func. Ptr */
  int x;
  int cmdopt_u = 0; /* -u; true if UNIX -> DOS */
  static int cmdopt_v = 0; /* --version */
  static int cmdopt_f = 0; /* --filter */
  int cmdx = 0; /* lopts[] index */
  char optch; /* current option character */
  static char optstr[] = "huf"; /* supported options */
  static struct option lopts[] = {
    { "help", 0, NULL, 'h' }, /* --help option */
    { "version", 0, &cmdopt_v, 1 }, /* --version option */
    { "filter", 0, &cmdopt_f, 'f' }, /* --filter option */
    { NULL, 0, NULL, 0 }
  };

  /* 
   * Determine the basename of the command name. This is necessary
   * since this command could be invoked with a pathname. For example
   * argv[0] could be "/root/proj/convertor/unixcvrt" if it was installed
   * in the system that way.
   */
  base_name = basename( argv[ 0 ] );

  /* 
   * Now that we know the basename of the command name used
   * we can determine which function we must carry out here.
   */
  if ( !strcmp( base_name, "unixcvrt" ) ) {
    /* perform a Unix --> Dos text conversion */
    /* printf( "Perorm Unix --> Dos conversion\n" );*/
    cmdopt_u = 1; /* pretend that -u was given */
  }

  /*
   * process all command line options.
   */
  while ( (optch = getopt_long( argc, argv, optstr, lopts, &cmdx )) != EOF ) {
    switch ( optch ) {
    case 0:
      break;
    case 'f':
      /*filter( base_name ); */ /* -f; filter */
      cmdopt_f = 1;
      break;
    case 'h': /* -h; request usage help */
      usage( base_name );
      return 0;
    case 'u': /* -u; specifies UNIX --> DOS text conversion */
      cmdopt_u = 1;
      break;
    default:
      fputs( "Use -h for help.\n", stdout );
      return 1;
    }
  }

  if ( cmdopt_v != 0 ) {
    fprintf( stdout, "Version 1.0\n" );
    return 0;
  }

  if ( cmdopt_f != 0 ) {
    filter( base_name );
    return 0;
  }

  /* chech for missing input file */
  if ( argc - optind < 1 ) {
    fprintf( stdout, "Missing input file(s).\n" );
    fprintf( stdout, "Use -h or --help for help.\n" );
    return 1;
  }

  /* 
   * -u determines the direction of conversion 
   */
  if ( cmdopt_u != 0 ) {
    conv = unix2dos;
  } else {
    conv = dos2unix;
  }

  /*
   * perform a text conversion.
   */
  for ( x = optind; x < argc; x++ ) {
    if ( (rc = conv(argv[x])) != 0 ) {
      break; /* an error occured */
    }
  }

  return rc;
}

/* End of $Source: /root/proj/convertor/doscvrt.c,v $ */
