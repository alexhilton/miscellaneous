/*
 * filename.h
 * $header$
 *
 * descriptions
 *
 * Author: Hitlion Warrior King
 *
 * Date: $Date$
 *
 * Revision Log:
 * $Log$
 */
#ifndef _file_h
#define _file_h "@(#) file.h $Revision$"


#endif /* file.h */

/* $Source$ */
