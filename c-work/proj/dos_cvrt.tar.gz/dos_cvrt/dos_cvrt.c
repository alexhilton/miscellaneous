/*
 * $Header: /root/c-work/proj/dos_cvrt.c,v 1.4 2007/12/09 09:00:41 root Exp $
 *
 * Hitlion.Warrior.King				$Date: 2007/12/09 09:00:41 $
 *
 * dos_cvrt.c a new unix text utility.
 *
 * Revision History
 * $Log: dos_cvrt.c,v $
 * Revision 1.4  2007/12/09 09:00:41  root
 * add error chekcing function.
 *
 * Revision 1.3  2007/12/08 23:23:41  root
 * add long option processing function.
 *
 * Revision 1.2  2007/12/08 22:53:53  root
 * add options processing function.
 *
 * Revision 1.1  2007/12/07 07:22:03  root
 * Initial revision
 *
 */
static const char rcsid[] = "$Id: dos_cvrt.c,v 1.4 2007/12/09 09:00:41 root Exp $";

#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include "dos_cvrt.h"


extern char *optarg;		/* option argument */
extern int optind;		/* option / arg index */
extern int opterr;		/* error handling flg */

/*
 * return the pointer to the basename componet of a pathname.
 */
static char *basename(
  const char *path
);

/* show brief command usage help: */
static void usage(
  const char *cmd
);

/* main program */
int main( int argc, char **argv )
{
  char *base_name = 0;			/* basename of command */
  int rc = 0;				/* command return code */
  /* conv. func. ptr */
  int ( *conv ) ( const char *pathname );
  int x;
  int cmdopt_u = 0;	/* -u ; true if unix --> dos */
  static int cmdopt_v = 0;   /* --version */
  int cmdx = 0; 	/* lopts[] index */
  int optch;		/* current option character */
  static char stropts[] = "hu";   /* supported options */
  static struct option lopts[] = {
    /* --help */
    { "help", 0, 0, 'h' },
    /* --version */
    { "version", 0, &cmdopt_v, 1 },
    /* no more options */
    { 0, 0, 0, 0 }
  };

  /* 
   * determine the base name of the command name. This is necessary
   * since this command could be invoked with a pathname. For example, 
   * argv[ 0 ] could be "/root/local/bin/unix_cvrt" if it was installed
   * in the system that way.
   */
  base_name = basename( argv[ 0 ] );
  if ( strcmp( base_name, "unix_cvrt" ) ) {
    /* pretend that -u was given */
    cmdopt_u = 1;
  }
 
  /* process all command lines */
  while ( ( optch = getopt_long( argc, argv, stropts,
    lopts, &cmdx ) ) != EOF ) {
    switch ( optch ) {
      /* processed lops[ cmdx ] */
      case 0:
	break;
      /* -h or --help; request usage help; */
      case 'h':
	usage( base_name );
	return ( 0 );
      /* -u; specifies unix-->dos */
      case 'u':
	cmdopt_u = 1;
	break;
      /* unsupported option */
      default:
	fputs( "use -h or --help for help.\n", stderr );
	return ( 1 );
    } 
  }
  
  if ( cmdopt_v != 0 ) {
    fprintf( stderr, "Version 1.0\n" );
    return ( 0 );
  }

  /* check for missing input file: */
  if ( argc - optind < 1 ) {
    fprintf( stderr, "missing input file(s).\n" );
    fputs( "use -h or --help for help.\n", stderr );
    return ( RC_CMDOPTS );
  }

  /* -u determines the direction of conversion: */
  if ( cmdopt_u != 0 ) {
    conv = unix2dos;
  } else {
    conv = dos2unix;
  }

  /* perform a text conversion */
  for ( x = optind; x < argc; x++ ) {
    if ( ( rc = conv( argv[ x ] ) ) != 0 ) {
      /* an error occured */
      break;
    }
  }
  /* 
   * check that out possibly buffered stdout gets
   * flushed without erros.
   */
  fflush( stdout );
  if ( ferror( stdout ) ) {
    fprintf( stderr, "%s: writing standard output\n",
      strerror( errno ) );
    rc = RC_WRITERR;
  }

  return ( rc );
}


static char *basename(
  const char *path
) {
  char *base_name = 0;

  if ( ( base_name = strrchr( path, '/' ) ) != 0 ) {
    base_name++;
  } else {
    base_name = ( char * ) path;
  }
  return ( base_name );
}
  

static void usage(
  const char *cmd
) {
  fprintf( stderr, "Usage: %s [-h |--help] [--version] [-u] infile..\n", cmd );
  fputs( "\t-h(or --help)\tGives this help display.\n", stderr );
  fputs( "\t-u\t\tSpecifies UNIX to DOS conversion.\n\n", stderr );
  fputs( "Command unix_cvrt converts UNIX to DOS text.\n", stderr );
  fputs( "while dos_cvrt converts DOS to UNIX , except " 
    "when -u is used.\n\n", stderr );
}
/* End $Source: /root/c-work/proj/dos_cvrt.c,v $ */
