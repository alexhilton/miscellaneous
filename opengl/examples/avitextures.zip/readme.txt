AVI Textures
------------

This project uses AVI video clips as textures for the objects. The AVI is loaded as a stream and each frame is extracted and made into a BMP. The BMP data is then copied into the texture data and the texture is updated. 

There are two projects in this .ZIP file. The first is a simple rotating cube. You can use your arrow keys to change the rotation of the cube.

The second project is based on an earlier project. Here the texture / video clip image is warped while its playing. 
For the second project, use your mouse to move the warp effect and the following keys :

Keys :
 - Space : Toggles between Lens and Twist
 - Keypad "+" : Increases the Effect of the lens/twist
 - Keypad "-" : Decreases the Effect of the lens/twist
 - Up Arrow   : Increases the Radius of the lens/twist
 - Down Arrow : Decreases the Radius of the lens/twist

Please note; if you are planning on using your own avi files, make sure they have a valid texture size (both widht and height must be dividable by 16). For example: 32x32, 128x128, 512x256 etc etc.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
