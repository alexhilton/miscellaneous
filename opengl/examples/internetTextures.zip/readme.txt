Internet Textures
-----------------

This project uses an http connection and windows API calls to download its textures from the internet. There are two textures are on my site and if you press 1 or 2 it will download the texture and assign it to the object.

NOTE : 
1.) The application takes a while to establish a connection to the site, but once that connection has been made it downloads those textures in a second.
2.) Using wininet is probably not the best solution because it doesn't return any errors. if the texture is not found a 404 error is created and returned as a page, so the app still sees some info returning. Using sockets or FTP will be a much better because it returns the file status.

Keys :
  1, 2 : Downloads the two textures.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
