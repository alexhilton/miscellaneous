C#.Net OpenGL Application Template
----------------------------------

This is the basic application template that I use to create my OpenGL applications in .net

To use this you will need to install the csgl assemblies.

These assemblies as well as instructions on how to use and install them can be found 
here : http://csgl.sourceforge.net/

If you have any queries or bug reports, please mail me.

Code : Maarten "McCLaw" Kronberger
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

