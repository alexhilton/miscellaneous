Tunel Text
----------

Initially I wanted to have the end titles for my demo coming down a tunnel on a rail displaying the coders and graphics artists names. A week after I completed the effect I saw it in another demo.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

