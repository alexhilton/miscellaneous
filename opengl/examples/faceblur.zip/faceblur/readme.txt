Face Blur
---------

FaceBlur is a face I got from a 3DS model and added some radialblur onto it. Created an interesting effect. This demo is quite CPU and graphically intensive. 

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

