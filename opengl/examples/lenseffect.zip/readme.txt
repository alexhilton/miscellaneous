Lens and Twist Effect
---------------------

I saw this effect is an old DOS demo and then in some windows screensavers, so naturally I had to try and do it myself :)

There is a basic lens effect that enlarges the image in the region of the lens. Then there is also a twist effect that twists the image in a certain radius.

While playing around, turn off the textures and have a look at the wireframe image to see what actually happens. Press "T" to toggle textures/wireframe

Keys :
 - Space : Toggles between Lens and Twist
 - "T"   : Toggles between Textured and wireframe image
 - Keypad "+" : Increases the Effect of the lens/twist
 - Keypad "-" : Decreases the Effect of the lens/twist
 - Up Arrow   : Increases the Radius of the lens/twist
 - Down Arrow : Decreases the Radius of the lens/twist

Move your mouse around to see the effect of the lens/twist of different parts of the screen.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

