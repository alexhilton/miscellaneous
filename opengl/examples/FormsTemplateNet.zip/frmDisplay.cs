//------------------------------------------------------------------------
//
// Author      : Maarten "McCLaw" Kronberger
// Email       : sulacomcclaw@hotmail.com
// Website     : http://www.sulaco.co.za
// Date        : 20 June 2003
// Version     : 1.0
// Description : This is the basic application template that I use 
//				 to create my OpenGL applications in .net
//				 To use this you will need to install the csgl assemblies.
//
//				 These assemblies as well as instructions on how to use and  
//				 install them can be found here : http://csgl.sourceforge.net/
//
//				 If you have any queries or bug reports, please mail me.
//
//------------------------------------------------------------------------

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CsGL.OpenGL;
using System.Threading;
using System.IO;

namespace OpenGL
{
	/// <summary>
	/// frmDisplay.
	/// </summary>
	public class frmDisplay : System.Windows.Forms.Form
	{
		// Window Title
		const string WND_TITLE = "OpenGL C#.Net App By McCLaw";
		
		// Setup of our Rendering View (DC and RC etc...)
		private SulacoGL.glView view = new SulacoGL.glView();
		
		// Rendering Thread
		private System.Threading.Thread thrDraw;
		
		// Timer for FPS
		private System.Windows.Forms.Timer FPSTimer;
		private System.ComponentModel.IContainer components;


		/********************************************************/
		/* Constructor of our form                              */
		/********************************************************/
		public frmDisplay()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			//
			// Add any constructor code after InitializeComponent call
			//
			
			this.view.Parent = this;
			this.view.Dock = DockStyle.Fill;

			// Start the Rendering Thread
			ThreadStart thrdDraw = new ThreadStart(glDraw);
			thrDraw = new Thread(thrdDraw);
			thrDraw.Start();
			
		}

		
		/********************************************************/
		/* External procedure for rendering scene in thread     */
		/********************************************************/
		private void glDraw()
		{
			while(Thread.CurrentThread.IsAlive)
			{
				this.view.Refresh();
				this.view.ProcessKeys();
			}

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/********************************************************/
		/* Clean up any resources being used.                   */
		/********************************************************/
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				thrDraw.Abort();
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDisplay));
			this.FPSTimer = new System.Windows.Forms.Timer(this.components);
			// 
			// FPSTimer
			// 
			this.FPSTimer.Enabled = true;
			this.FPSTimer.Interval = 500;
			this.FPSTimer.Tick += new System.EventHandler(this.FPSTimer_Tick);
			// 
			// frmDisplay
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 566);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.Name = "frmDisplay";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "OpenGLApp By McCLaw";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmDisplay());
		}
		
		/********************************************************/
		/* Timer event to calculate our FPS                     */
		/********************************************************/
		private void FPSTimer_Tick(object sender, System.EventArgs e)
		{	
			// calculate to get per Second incase intercal is less or greater than 1 second
			int FPSCount = this.view.CalculateFPSCount(FPSTimer.Interval);
			this.Text = WND_TITLE + "   [" + FPSCount.ToString() + " FPS]";
		}
	}
}

namespace SulacoGL
{
	/// <summary>
	/// Basic Class for viewing OpenGL Form
	/// </summary>
	public class glView : OpenGLControl
	{		
		// Timer Vars
		public int FPSCount  = 0;            // Counter for FPS
		public int ElapsedTime = 0;          // Elapsed time between frames
		public long DemoStart = 0;
		// Holds keystrokes
		bool[] keys = new bool[255];   

		// Texure Variables
		protected OpenGLTexture2D CubeTexture;

		// User variables
		private float xAngle,yAngle,xSpeed, ySpeed;
		
		/// <summary>
		/// Default Constructor
		/// </summary>
		public glView(): base()
		{
			
			/*
			 These styles are set by base constructor
						SetStyle(ControlStyles.AllPaintingInWmPaint, true);
						SetStyle(ControlStyles.Opaque, true);
						SetStyle(ControlStyles.ResizeRedraw, true);
						SetStyle(ControlStyles.UserPaint, true);
						SetStyle(ControlStyles.DoubleBuffer, false);
			*/

			// events
			this.KeyDown += new KeyEventHandler(glView_OnKeyDown);
			this.KeyUp += new KeyEventHandler(glView_OnKeyUp);

			// vars
			
			CubeTexture = LoadTexture("ball.bmp");
			
			DemoStart = Environment.TickCount;            // Get Time when demo started

		}

		/********************************************************/
		/* Load Image from correct path                         */
		/********************************************************/
		private OpenGLTexture2D LoadTexture(string strFileName)
		{
			string strAppPath = Application.StartupPath;

			//Does the texture exist in the running path? (DEBUG/RELEASE)
			if(File.Exists(strAppPath + "\\" + strFileName))
			{
				return new OpenGLTexture2D(strAppPath + "\\" + strFileName);
			}

			//Does texture Exist in parent directory? (BIN)
			strAppPath = strAppPath.Substring(0,strAppPath.LastIndexOf("\\"));

			if(File.Exists(strAppPath + "\\" + strFileName))
			{
				return new OpenGLTexture2D(strAppPath + "\\" + strFileName);
			}

			//Does texture Exist in parent directory?(PROJECT DIR)
			strAppPath = strAppPath.Substring(0,strAppPath.LastIndexOf("\\"));

			if(File.Exists(strAppPath + "\\" + strFileName))
			{
				return new OpenGLTexture2D(strAppPath + "\\" + strFileName);
			}

			// Texture doesnt exist in the search paths so throw an error
			throw(new FileNotFoundException(strFileName + " Could not be found,\r\nCheck if this texture exists in the main, debug or release folder",strFileName));

		}
		/********************************************************/
		/* Calculate the FPS                                    */
		/********************************************************/
		public int CalculateFPSCount(int interval)
		{
			// calculate to get per Second incase intercal is less or greater than 1 second
			FPSCount = (int)Math.Round(FPSCount * (double)1000/(double)interval);   
			int ResultFPS = FPSCount;
			FPSCount = 0;
			return ResultFPS;
		}


		/********************************************************/
		/* Processes all the keystrokes                         */
		/********************************************************/
		public void ProcessKeys()
		{
			if (keys[(int)Keys.Up] || keys[(int)Keys.W])	xSpeed -= 0.002f;
			if (keys[(int)Keys.Down] || keys[(int)Keys.S])	xSpeed += 0.002f;
			if (keys[(int)Keys.Right] || keys[(int)Keys.D])	ySpeed += 0.002f;
			if (keys[(int)Keys.Left] || keys[(int)Keys.A])	ySpeed -= 0.002f;
		}

		/******************************************************************/
		/* Function to draw the actual scene                              */
		/******************************************************************/
		public override void glDraw()
		{	

			// FPS And Elapsed Time Calculations
			FPSCount++;

			int LastTime = ElapsedTime;
			ElapsedTime = Environment.TickCount - (int)DemoStart;     // Calculate Elapsed Time
			ElapsedTime = (LastTime + ElapsedTime) / 2; // Average it out for smoother movement
			
			//OpenGL Code
			GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);	
			GL.glLoadIdentity();			
			
			GL.glTranslatef(0.0f,0.0f,-5.0f);
			
			//--- There are two types of movement. Select the type you want to use ---//
			// For movement that requires used input use ... //
			GL.glRotatef(xAngle, 1, 0, 0);
			GL.glRotatef(yAngle, 0, 1, 0);

			// For movement that requires a constant speed on all machines use ... //
			//   GL.glRotatef(ElapsedTime/20, 1, 0, 0);
			//   GL.glRotatef(ElapsedTime/30, 0, 1, 0);
			
			
			CubeTexture.Bind(); // Bind the Texture to the object
			GL.glBegin(GL.GL_QUADS);
				// Front Face
				GL.glColor3f(1.0f,0.0f,0.0f);
				GL.glNormal3f( 0.0f, 0.0f, 1.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f(-1.0f, -1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f( 1.0f, -1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f( 1.0f,  1.0f,  1.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f(-1.0f,  1.0f,  1.0f);
				// Back Face
				GL.glNormal3f( 0.0f, 0.0f,-1.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f(-1.0f, -1.0f, -1.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f(-1.0f,  1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f( 1.0f,  1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f( 1.0f, -1.0f, -1.0f);
				// Top Face
				GL.glNormal3f( 0.0f, 1.0f, 0.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f(-1.0f,  1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f(-1.0f,  1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f( 1.0f,  1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f( 1.0f,  1.0f, -1.0f);
				// Bottom Face
				GL.glNormal3f( 0.0f,-1.0f, 0.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f(-1.0f, -1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f( 1.0f, -1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f( 1.0f, -1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f(-1.0f, -1.0f,  1.0f);
				// Right face
				GL.glNormal3f( 1.0f, 0.0f, 0.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f( 1.0f, -1.0f, -1.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f( 1.0f,  1.0f, -1.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f( 1.0f,  1.0f,  1.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f( 1.0f, -1.0f,  1.0f);
				// Left Face
				GL.glNormal3f(-1.0f, 0.0f, 0.0f);
				GL.glTexCoord2f(0.0f, 0.0f); GL.glVertex3f(-1.0f, -1.0f, -1.0f);
				GL.glTexCoord2f(1.0f, 0.0f); GL.glVertex3f(-1.0f, -1.0f,  1.0f);
				GL.glTexCoord2f(1.0f, 1.0f); GL.glVertex3f(-1.0f,  1.0f,  1.0f);
				GL.glTexCoord2f(0.0f, 1.0f); GL.glVertex3f(-1.0f,  1.0f, -1.0f);
			GL.glEnd();

			xAngle += xSpeed;
			yAngle += ySpeed;

			
		}

		/// <summary>
		/// Initialise OpenGL
		/// </summary>
		/******************************************************************/
		/* Initialise OpenGL                                              */
		/******************************************************************/
		protected override void InitGLContext() 
		{
			GL.glClearColor(0.0f, 0.0f, 0.0f, 0.0f); 	// Black Background
			GL.glShadeModel(GL.GL_SMOOTH);				// Enables Smooth Color Shading
			GL.glClearDepth(1.0f);						// Depth Buffer Setup
			GL.glEnable(GL.GL_DEPTH_TEST);              // Enable Depth Buffer
			GL.glDepthFunc(GL.GL_LESS);					// The Type Of Depth Test To Do

			GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);   //Realy Nice perspective calculations

			GL.glEnable(GL.GL_TEXTURE_2D);				// Enable Texture Mapping

			xSpeed = 0.1f;								// start with some movement
			ySpeed = 0.1f;
		}

		/// <summary>
		/// Handle window resize
		/// </summary>
		/// <param name="e">EventArgs</param>
		/******************************************************************/
		/* Handle window resize                                           */
		/******************************************************************/
		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e); //Pass the event on
		
			Size s = Size; // Window Size
			double aspect_ratio = (double)s.Width /(double) s.Height;

			GL.glMatrixMode(GL.GL_PROJECTION);
			GL.glLoadIdentity();
			GL.gluPerspective(45.0f, aspect_ratio, 0.1f, 100.0f);
	
			GL.glMatrixMode(GL.GL_MODELVIEW);
			GL.glLoadIdentity();
		}

		/// <summary>
		/// OnKeyDown Event Handler
		/// </summary>
		/// <param name="Sender">object from the sender</param>
		/// <param name="kea">kea KeyEventArgs</param>
		/******************************************************************/
		/* OnKeyDown Event Handler                                        */
		/******************************************************************/
		protected void glView_OnKeyDown(object Sender, KeyEventArgs kea)
		{
			keys[kea.KeyValue] = true;
			
			if (kea.KeyCode == Keys.Q && kea.Modifiers == Keys.Shift) //Exit
			{
				Application.Exit();
			}
			if (kea.KeyCode == Keys.F1) //Fullscreen
			{
				Form form = (Form)this.Parent;// boxing need for formborderstyle

				if (form.Size.Height == SystemInformation.VirtualScreen.Height)
				{
					form.FormBorderStyle = FormBorderStyle.Fixed3D;
					form.Size = new Size(800,600);
					form.Location = new Point(SystemInformation.VirtualScreen.Width / 5,
						SystemInformation.VirtualScreen.Height / 5);
				}
				else 
				{
					form.FormBorderStyle = FormBorderStyle.None;
					form.Size = new Size(SystemInformation.VirtualScreen.Width,
						SystemInformation.VirtualScreen.Height);
					form.Location = new Point(0,0);
				}
			}
		}


		/// <summary>
		/// OnKeyUp Event Handler
		/// </summary>
		/// <param name="Sender">object from the sender</param>
		/// <param name="kea">kea KeyEventArgs</param>
		/******************************************************************/
		/* OnKeyUp Event Handler                                          */
		/******************************************************************/
		protected void glView_OnKeyUp(object Sender, KeyEventArgs kea)
		{
			keys[kea.KeyValue] = false;
		}
	}

}

