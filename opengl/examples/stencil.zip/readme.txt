Stencil buffer as a mask
------------------------

Stenciling, like z-buffering, enables and disables drawing on a per-pixel basis. You draw into the stencil planes using OpenGL drawing primitives, then render geometry and images, using the stencil planes to mask out portions of the screen

I have added three examples to demonstrate this.

- Stencil1 : First draws a square in the stencil buffer. The a wireframe knot is drawn in that mask, so it only appears in the square. The same knot is drawn filled on the scene where the stencil mask dot not appear.

- Stencil 2 : Same as above, but it renders the knot in the square area.

- Stencil 3 : Same idea, but here the knot is the mask that is created in the stencil buffer and the textured square is then drawn on that mask.


Move your mouse around to move the square in Stencil 1 and 2.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn




