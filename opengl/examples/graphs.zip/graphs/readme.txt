Graphs - Graphical Expression Viewer
------------------------------------

You can use this program to create graphs using common mathematical functions. There application in written in such a way that you can plug in any expression evaluator with minimal code changes. I have tried three other expression evaluators an never had to change more than 4 lines of code.

Type in the expression at the top, select the range and increment of your variables and create the graph. There are a few pre-built functions that create interesting graphs.

Use your mouse to move and rotate the graphs. 

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
