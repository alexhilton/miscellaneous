Skyboxes
--------

I quickly put together this example of a skybox. I dont know if its the proper way of doing it, but it works.  

Keys : 
 Arrow keys - rotate the scene

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
