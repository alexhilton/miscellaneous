3D Font demo
~~~~~~~~~~~~

This project demonstrates how to get display lists of windows fonts.
It uses the "wglUseFontOutlines" function.

This function also returns a list of character sizes. In the demo
there's an array "gFontSizes" declared which has 1024 elements. The
fontlist which is created only contains 256 elements however if i
lower the upperbound value of the "gFontSizes" array then i get an
access violation.

If you have any questions or remarks please mail me

Code    : Arno van der Vegt, template by Jan Horn
Website : http://www.sulaco.co.za
Mail    : info@wheelcompiler.org

