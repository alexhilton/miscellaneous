Plasma Colors
-------------

This program creates the look of a plasma effect using multiple layers of images blended with each other. Adding more layers adds to the "plasma" effect.

The number of layers used is displayed in the title bar
- 10 layers makes some nice color effects
- 20 layers creates a good looking plasma effect

Keys :
 - "T" : Select the next texture.
 - "B" : Enable/Disable the bacground
 - "+" : Increase the number of layers
 - "-" : Decrease the number of layers

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

