Delphi OpenGL Application Template1.5
-------------------------------------

This is the basic application template that I use to create my OpenGL applications

This version implements all the OpenGL extentions up to OpenGL 1.5

The dglOpenGL.pas file was created by the team at www.delphigl.com
I have included the html readme for an explanation of using this.

If you have any queries or bug reports, please mail me.

Code : Maarten "McCLaw" Kronberger
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

