Projected Textures
------------------

Projected textures is actually quite simple. Basically all you have to do is render to the texture view instead of the model view. There are a few other thing you need to setup to get it working correctly, but then there isn't much to see.

In this project I created a standard scene and then blended the projected texture onto this scene (Thanks to Tom Nuydens project for this idea - www.delphi3d.net). This gives the impression of a projector shining a light into the room. A nice addition to this could be to use an avi at the projected texture. 

Keys and mouse :
  "Space" : Start and stop the animation
  Click on the sphere and drag it around the scene

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn