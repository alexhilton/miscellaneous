Peristalsis
-----------

A small program that does some cool OpenGL effects. Its basically a cylinder that 
turns anti-clockwise around the screen. The cyliner also gets twisted along the 
central axis. The radius of the cylinder changes in different places. The X 
position of the cylinder moves according to a complex sin wave.

If you plan to use this effect somewhere else, please mention my name and URL.

Keys 
  W : Wireframe mode
  T : Texured surfaces

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

