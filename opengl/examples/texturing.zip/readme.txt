An Experiment in Texturing
--------------------------

I got an idea to use multi-texturing and The texture matrix to do some cool effects.

This was the end result.

If you have any queries or bug reports, please mail me.

Code : Maarten "McCLaw" Kronberger
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

