Landscape Generator with heightmap
----------------------------------

Based on NeHe's Tutorial 35 (http://nehe.gamedev.net). 
I've added color to the emphasize the differences in the height
of the landscape and added "contour" lines. They are not true 
contour lines, but help to give an indication of the space of 
the landscape

Keys : 
  UP Arrow   - go forward
  DOWN Arrow - go backward


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

