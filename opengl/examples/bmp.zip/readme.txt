BMP Loader
----------

BMP.pas
-------
A BMP texture loader. Will load a 24bit BMP as a texture. 
BMP dimensions have to be 8x8, 16x16, 32x32, 64x64, 128x128, 256x256 or 512x512.

To use this unit
- Include the unit in your Uses clause
- Declare the texture in your main program (eg. MyTexture : glUint; )
- Call the load function. LoadTexture('images/mytexture.bmp', myTexture);

There is a sample app included showing you how to use it.


BMP2.pas
--------
Same as above, but it allows you to load textures from file or from the application resource.
To load from file, you would use LoadTexture(...)
To load from resource, use LoadResTexture(...)


If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

