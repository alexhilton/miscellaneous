Active Backgrounds
------------------

The initial idea of this program was to allow one to have a active background while displaying some interesting demo effects in the foreground.
The program was created using Borland Delphi. All source code is included.


Keys :
  1, 2, 3 : different background effects.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

