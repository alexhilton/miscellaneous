Texture Light Generation
-------------------------

This app demonstrates how to render the effects of a simple light on objects using blending. 

One textured polygon is positioned over the background and the blended with it using glEnable(GL_BLEND);.

Use your Arrow keys to move the light beam and "b" to toggle the light switch


If you have any queries or bug reports, please mail me

Code : Maarten Kronberger (McCLaw)
Mail : maartenk@tinderbox.co.za	
Web  : http://www.sulaco.co.za
       http://www.tinderbox.co.za