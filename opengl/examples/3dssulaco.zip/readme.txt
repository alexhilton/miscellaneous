*****************************************************************************************
19/11/2003

WHAT THE T3DMODEL CLASS DOES NOT DO.
------------------------------------

1.- 3D Studio stores the materials "per face". This version of T3DModel imports only one material per object.
    In next releases this improvement can be done.

2.- T3DModel class does not allow to assign textures in runtime, because it is a class to import 3ds files.

3.- T3DModel class does not import Keyframe animation.


T3DMODEL CLASS HINTS
--------------------

1.- Because 3D Studio does not export the normals, T3DModel Class does it for you, but the method to do this
    is averaging face normals and apply the result to the coincident vertices of faces. For the most of the objects
    is a valid method, but not for those that require sharpened faces. In next releases this improvement can be done.



*****************************************************************************************




T3DModel
  T3DObject
     TMaterial
       TMaterialProperties
     TTransformList
       TTransform  




--------
T3DModel
--------

    Objects:array of T3DObject;                              Immediate access to individual objects
    function AddObject:T3DObject;                            Adds an individual 3DObject
    procedure Clear;                                         Cleanup the model  
    procedure VisibleAll;                                    All objects are visible
    function LoadFromFile(const FileName:string):Boolean;    Load a 3Dmodel from file
    function FindObject(const aName:string):T3DObject;       Find one object by the 3ds name
    function Select(const Index:Integer):T3DObject;          Select one object by the 3ds creation order
    procedure Draw;                                          Draws the complete model
    property ObjectCount:Integer read GetObjectCount;        


---------
T3DObject
---------


    Verts:array of TVector3D;                                                Immediate acces to vertices
    Normals:array of TVector3D;                                              Immediate access to normals
    TexVerts:array of TVector2D;                                             Immediate access to texture vertices   
    Faces:array of TFace;                                                    Immediate access to faces
    procedure Draw;                                                          Draws this object 
    property Visible:Boolean read FVisible write FVisible;                   The object is visible
    property ObjectName:string read FObjectName write FObjectName;           3ds object name
    property Material:TMaterial read FMaterial;                              Object material 
    property VertexCount:Integer read FVertexCount;
    property TexVertexCount:Integer read FTexVertexCount;
    property FaceCount:Integer read FFaceCount;
    property NormalCount:Integer read FNormalCount;
    property ObjectIndex:Integer read FObjectIndex;                          3ds object index
    property RenderMode:TRenderMode read FRenderMode write SetRenderMode;    (rmTriangles, rmPoints, rmLines)
    property TransformList:TTransformList read FTransformList;               Transformation list for this object  
    property Selected:Boolean read FSelected write FSelected;                The object has been selected 


---------
TMaterial
---------


    Shininess, Transparency:Single;
    procedure SetMaterialColor(const MaterialType: TMaterialType;                (mtAmbient, mtDiffuse, mtSpecular)
                                const R, G, B, Alpha:Single);
    property HasTexture:Boolean read FHasTexture;
    property DisableTexture:Boolean read FDisableTexture write FDisableTexture;
    property EnviromentMap:Boolean read  FEnviromentMap write FEnviromentMap;
    property SphericalMap:Boolean read  FSphericalMap write FSphericalMap;
    property GenTexture:Cardinal read FGenTexture write FGenTexture;
    property MaterialName:string read FMaterialName;                             Name of the 3ds material 
    property MaterialFile:string read FMaterialFile;                             File of texture
    property Ambient:TMaterialProperties read FAmbient;                          3ds ambient material
    property Diffuse:TMaterialProperties read FDiffuse;                          3ds diffuse material 
    property Specular:TMaterialProperties read FSpecular;                        3ds specular material
    property Emission:TMaterialProperties read FEmission;                        There is no emission on 3ds file, but the object


-------------------
TMaterialProperties
-------------------

    function ToString:string;                                              RGBA values
    procedure SetRGBA(const R, G, B, Alpha:Single);                        Set individual RGBA
    procedure Apply;                                                       Apply the material to his object
    property Vector:TVector4f read FVector write FVector;                  RGBA vector (Vector.Red, Vector.Green ...)
    property Color:TColor read GetColor write SetColor;                    TColor for the material (clGreen, clBlue ...)
    property Alpha:Single read FVector.Alpha write FVector.Alpha;          Alpha value for the material



--------------
TTransformList
--------------

    procedure Push;                                                      Push the Transformation objects if enabled
    procedure Pop;                                                       Pop transformation objects if enabled
    property Enabled:Boolean read FEnabled write FEnabled;               Enable transformations 
    function AddTransform:TTransformation;                               Adds undefined transformation
    function AddTransformEx(const _TransformType:TTransformType;         Add defined transformation
                            const _Angle, _X, _Y, _Z:Single):             (ttTranslate, ttRotate, ttScale)
                            TTransformation;


---------------
TTransformation
---------------

    procedure Apply;                                                     Apply this transformation
    procedure Restore;                                                   Restore this transformation
    property Angle:Single read FAngle write FAngle;
    property TransformType:TTransformType read FTransformType write FTransformType;
    property X:Single read FX write FX;
    property Y:Single read FY write FY;
    property Z:Single read FZ write FZ;
    property Enabled:Boolean read FEnabled write FEnabled;
    property Pushed:Boolean read FPushed write FPushed;