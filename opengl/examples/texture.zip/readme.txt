Texture Loader
--------------

A BMP, JPG and TGA texture loader. Will load a 24bit BMP, JPG or TGA files as a textures. 
The texture can also be loaded from the applications resource file.
Image dimensions have to be 8x8, 16x16, 32x32, 64x64, 128x128, 256x256 or 512x512 ...

To use this unit
- Include the unit in your Uses clause
- Declare the texture in your main program (eg. MyTexture : glUint; )
- Call the load function. LoadTexture('images/mytexture.jpg', myTexture, FALSE);

The third parameter specifies the location to load from. FALSE means it must not
load the application resource. TRUE tells the loader to get the image from the resource.

There is a sample app included showing you how to use it. If the sample app does not work on older versions of Delphi (before 5), Please let me know sothat I can sort it out.

History
-------
 - Version 1.02 (2 October)
   * Added support for 32bit TGA files. 24bit color and 8bit Alpha

 - Version 1.01 (1 May 2001)
   * Optimised the resource loading code. Loads a lot faster now
   * Changed the resource identifier for JPG files. Use to be JPEG, but
     now its JPG to match BMP and TGA

 - Version 1.0 (8 April 2001)

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

