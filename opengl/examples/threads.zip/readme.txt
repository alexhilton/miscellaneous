Threads
-------

This program uses line strips that follow your mouse cursor to create some neat line effects. I have also thrown in a simple startfield to give a forward motion effect.

You can also apply smooth shading (at the expense of some fps) which creates a nice smudging effect.

Keys : 
  S : enable/disable smooth shading
  1-9 : change the density of the threads. 9 is very spaced out threads.
  Use the + and - on your keypad to add and remove threads to get smoooth motion.

Mouse : move it around to see the effect.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
