Tinderbox Tunnel
----------------

I was trying to think of a use for GL picking besides the obvious, a
menu. I then came up with the idea for this program. Its a tunnel
that scrolls some of the websites past that Tinderbox (the company 
that I work for) has created. When you click on the browser image, 
the website is launched.

Keys :
 - Left and Right arrows to change the speed of the scrolling windows

Mouse : 
 - click on the browser image to launch the site.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

