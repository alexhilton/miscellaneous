Bumpmapping
-----------

For this project I tried to create a "cheap" for of bumpmapping. i.e bumpmapping without all the normal and light calculation which has low CPU overhead.

If you want a proper implementation of bumpmapping have a look at tutorial 22 on nehe.gamedev.net

What this program does is to combine the bumb texture with the background and then have another copy of the bumptexture slightly offset depending on the light position. this give the illusion of a shadow.

Keys : 
  Keypad +/- : Adjust the amount of bumpmapping
  Space : Toggles textured background on and off

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn