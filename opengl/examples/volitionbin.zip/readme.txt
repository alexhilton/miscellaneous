                             Volition
                             ---------

Volition - Demo, Released on 14 Jan 2004 for Nehe's Creative Labs Europe 2004 Demo Contest

I HAVE READ, AND FULLY UNDERSTAND THE LEGAL ISSUES AS STATED ON THE NEHE PRODUCTIONS WEB SITE
IN REGARDS TO THE CREATIVE 2003 CONTEST. 

Demo Requirements
  System........      win98/win2k or higher with OpenGL
  Cpu...........      Pentium 3 or athlon recommended.
  Video.........      opengl accelerated 3d card. Geforce 2 or up
  Audio.........      windows compatible soundcard.
  
I have tested the demo on a P3-733 with a Geforce 2 video card running at 800x600. It runs OK, 
but occasionally the frame rate drops to 40fps.

Demo created by 
  Code..........      Maarten "McCLaw" Kronberger.
  Design........      Maarten "McCLaw" Kronberger and Bluespill Design
  Graphics......      Maarten "McCLaw" Kronberger and Bluespill Design
		      Caustic textures by Michael "Custard Slice" Wallace 
  Music by......      Volition, courtesy of Mystic Sound Theater

Compiled for the windows platform using Borland Delphi 6.  
 

The demo includes the bass.dll which enables it to play the MOD file.
BASS is a sound system for use in Windows 95/98/2000/NT software. 
It's purpose is to provide powerful (yet easy to use) sample, stream,
MOD music, and audio CD playback functions.

The latest version of BASS can always be found at the BASS homepage:
http://www.un4seen.com/music/



For this demo and many others all containing full source code, 
visit my website at : http://www.sulaco.co.za

If you have any queries or bug reports, please mail me.

Name : Maarten "McCLaw" Kronberger
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

