Texture detail demo
-------------------------------------

Discription:

Based uppon the texture loading unit of jan horn this texture
loader can load jpg and bmp, with different detail settings
and filters.

Keys:

F1 : Very high texture detail
F2 : high texture detail
F3 : medium texture detail
F4 : low texture detail
F5 : Very low texture detail

Disclamer:

This unit is part of the EYE engine system. This program is distributed in
the hope that it will be useful,but WITHOUT ANY WARRANTY. If you use it in
any way please give e credit for my work.

Contact:

If you have any queries or bug reports, please mail me.

Author      : Luuk van Venrooij
Email       : Luuk _van_Venrooij@progrock.com
Website     : http://www.il.fontys.nl/~seriva/

