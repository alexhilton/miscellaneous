Tangent Bumpmapping using nVidias Cg
-------------------------------------

Tangent Bumpmapping using nVidias Cg
Originally done by S�ren Dreijer (Halloko)
http://www.blacksmith-studios.dk
Thanx for all the help dude :)

This Code also uses the VectorGeometry.pas from glscene.org

Please note: I have included all the relevant units, and dll's,
but its always a good idea to look at the originating sites to get the latest versions

Code : Maarten "McCLaw" Kronberger
Mail : sulacomcclaw@hotmail.com
Web  : http://www.sulaco.co.za

