Render To Multiple Faces
------------------------

This project is very similar to a previous one called Render To Texture. What I tried to demonstrate there was using the glCopyToTexture function to create multiple copies of an object to save CPU time.

In this example the face that gets rendered has 800 triangles. Now I can make 500 copies of it floating all over the screen and blending with each other and still get over 60fps on my celeron 800.

Keys : 
  numeric pad + and - to add remove faces.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn