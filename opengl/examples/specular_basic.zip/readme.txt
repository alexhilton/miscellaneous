Specular Highlighting
----------------------

This little project uses specular highlighting on a non-textured object. 
The is one light source and the material has a very reflective surface.

I have added an extra feature that is only supported on cards/drivers 
that support OpenGL 1.2.  It's a GL extension that improves the effect
a LOT, but has a slight performance hit.  Press N to enable the 
GL_EXT_separate_specular_color and look at the difference.

Keys :
 - "N" : Toggle the GL_EXT_separate_specular_color extension.
 - "+" : Increases the number of segments in the torus, thereby
         increasing the quality
 - "-" : Decreases the number of segements

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

