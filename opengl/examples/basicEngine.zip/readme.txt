Basic 3D Engine
---------------

Here is a really basic 3D engine that should help you get started on your own engine. If you have already built an engine before, then this probably wont be of much use.

With this basic engine I have added a map file as well as some textures.

This 3d engine has frame rate independent movement so it should work the same on all machines.

The movement is the same as quake or unreal where you look around with your mouse and move around using your arrow keys. Left and right are for strafing.

There is a constant for mouse speed, so the user can adjust there mouse speed.

There is no collision detection at this stage. 

If you do plan to write a 3D engine, read up on BSP trees. They are essential for bigger maps.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn