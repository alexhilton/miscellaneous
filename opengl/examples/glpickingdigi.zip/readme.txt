Delphi Object picking tutorial
----------------------------------

How to pick an object in OpenGL using mouses. Can also be applied to crosshairs and HUD once it's understood.

Original Code : GameTutorials.com - Ben Humphrey
Delphi template: Jan Horn
Tutorial translation: David Caouette
       
BUG: In windowed mode, the window has to be resized to make the picking work correctly.