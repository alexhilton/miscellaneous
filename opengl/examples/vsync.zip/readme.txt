Enabling / Disabling V-Sync (Vertical Synchronization)
------------------------------------------------------

Philippe Dargent Sent me this brilliant piece of code 
showing how to Enable or Disable V-sync in OpenGL.

With V-sync Disabled I get approx. 240 FPS on my Geforce MX 440.

There are a few drawbacks to disabling V-sync.

You can read about these here: 

http://www.esreality.com/?a=longpost&id=522789&page=1


Code : Philippe Dargent
Mail : pdargent@interfacedata.fr
Web  : http://www.sulaco.co.za

