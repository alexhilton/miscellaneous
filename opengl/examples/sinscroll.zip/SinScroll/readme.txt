Font Sinusoidal Scrolling
------------------------------------------------------

Press x, y, z, 1, 2, 3, or 4 to change axis sinusoidal deformation


Code : Philippe Dargent
Mail : pdargent@interfacedata.fr
Web  : http://www.sulaco.co.za

