The Cube of Power
-----------------

Ok. This is just a cube... A cube of power of 3D Graphics.
Very simple OpenGL example that shows how to create Your's
first 3D scene.

Author
------
Dmitriy Apraksin
WEB: dwebplace.com
E-Mail: contact@dwebplace.com
