LANDSCAPE
---------

This is little landscape flying OpenGL example. In most
cases creating good landscape rendering engine is not a
simple task. But for who just start study of OpenGL and
3D graphics this simple example is more preferred.

In this example shown how to create with simple C code
and OpenGL some landscape. Just in 6K of code.

Author
------
Dmitriy Apraksin
WEB: dwebplace.com
E-Mail: contact@dwebplace.com
