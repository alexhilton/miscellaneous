Cubemapping using GL_REFLECTION_MAP_EXT 
--------------------------------------

This tutorial shows how to use the GL_REFLECTION_MAP_EXT and GL_TEXTURE_CUBE_MAP extensions to render a reflective Cube map 

The dglOpenGL.pas file was created by the team at www.delphigl.com
I have included the html readme for an explanation of using this.

If you have any queries or bug reports, please mail me.

Code : Maarten "McCLaw" Kronberger and Vereshagin Roman Vladimirovich
Mail : sulacomcclaw@hotmail.com and support@sibvrv.com
Web  : http://www.sulaco.co.za and http://www.sibvrv.com
