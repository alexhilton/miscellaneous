Electric Spheres
----------------

There are two porjects in the sip. A basic electric bolt and then the main project. The project shows how to create a bolt of electricity.

In the app I have two spheres with a constant spark between them. If one of them get close enough to a third sphere a spark is shot across to that sphere.


Keys :
  keypad + and - : Adds and decreases the threads in the spark.


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
