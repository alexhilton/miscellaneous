Projected Shadows
-----------------

There are a few way to do projected shadows. This is just one of them. For another implementation have a look at www.delphi3d.net

With very little extra code you can add multiple light sources and more objects.

When the demo starts the light source will move around by itself on the screen. You can use you mouse to control the position of the light.

Mouse : 
  Left click and drag - move the light source up, down, left and right
  Right click and drag - move the light source into and out of the scene

I know the controls aren't perfect, but that is not the point of this demo.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn