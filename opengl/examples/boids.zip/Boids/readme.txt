Project Description
-------------------

Author      : Maarten "McCLaw" Kronberger
Email       : sulacomcclaw@hotmail.com
Website     : http://www.sulaco.co.za
Date        : 18 September 2003
Version     : 1.0
Description : 2D Boids(Flocking) in OpenGL
              This project shows how schools of fish interact with one another.
              Same species try to stay togeter, and also try to chase away other species.
              Version two will feature, births, deaths and genetic memory tranference and mutation.
              Future versions will also use 3 Dimentional computations. 
	      (Currently I'm cheating *Blush*)
              
              Original Java Code Written by Josh Lifton
              Caustic Textures from Michael Wallace

Keys
----
"L" Toggles Friend lines
"K" Toggles Enemy Lines


Special Thanks to Scott Price for helping me with the memory issues.
