Quake 3 BSP Loader
------------------

This is a very basic Quake 3 BSP map file loader. All it does is to read the basic map structure and the textures it needs to use.

At this stage lightmaps, POV, collision detection and scripts have not yet been included.

Most of the code in this project is based on the BSP tutorial on www.gametutorials.com.
For more on BSP files and the tutorial, visit http://www.gametutorials.com/Tutorials/OpenGL/Quake3Format.htm


Keys and mouse :
  "W" : Toggle wireframe mode on and off
  Use your arrows keys to move around and the mouse to look.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn