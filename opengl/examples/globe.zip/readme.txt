Earth at Day and Night
----------------------

This is a shpere with a texture mapping of earth during the day and earth during the night on it.  

Keys :
 - Space : Switch between day and night
 - Arrow keys : Rotate earth in differenct Directions.
 - PgUp, PgDn : Zoom in and out.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
