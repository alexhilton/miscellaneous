GLPicking
---------

A very basic program demonstrating the use ofthe selectnio buffer in OpenGL. By clicking on the rotating spheres you can make them disappear. The reset button will return everything back to the default setup.

How does the program work ... ?

1.) You have to create the selection buffer
      glSelectBuffer(64, @selectBuff);
2.) Set the render mode to GL_SELECT and clear the buffers
      glRenderMode(GL_SELECT);
      glInitNames();
      glPushName(0);
3.) Create a new viewport at the position you clicked, but make the width and height very narrow
    gluPickMatrix(x, height-y, viewwidth, viewheight, @viewport);
4.) Draw the scene. When drawing the scene you have to loadthe names of the objects.
5.) Change back to rendering mode and get the number of hits. An object gets a hit if it appears in the scene drawn in the new viewport. 
    hits := glRenderMode(GL_RENDER);
6.) From the selection buffer you can now get the objects that were hit.
      SelectedName := selectBuff[3];
7.) Reset all views back to modelview for further rendering


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

