Plasma
------

I was spending some time on my computer looking through some of the effects I use to do in turbo pascal 7. I came across a old plasma effect and though "its a pity you can do this in opengl because it pixel based.". When looking through the old pascal source it suddenly occured to me that I was writing to the video memory ($A000). To get it working in openGL, all I needed to do was write to the texture memory.
10 minutes later these two applications were created.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
