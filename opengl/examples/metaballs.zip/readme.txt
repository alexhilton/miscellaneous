Metaballs 
---------

I have always wanted to create metaballs, and finally did. This is mostly thanks to the article put up by Paul Burke (http://www.swin.edu.au/astronomy/pbourke/modelling/). There you will find an excellent explanation on how the marching cubes algorithm works.

This is still quite a simple implementation of metaballs. At some stage I want to add environment mapping so that the balls could reflect the environment around them.

Keys :
 - S : Enable/Disable smooth shading
 - W : Toggle wireframe / shaded drawing
 - +/- : increase/decrease the size of the grid. This affects the quality of the metaballs.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

