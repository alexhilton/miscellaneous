------------------------------------------------------------------------
 Pixel shader demonstrator compiled by Cheb
 from Jan Horn's Delphi OpenGL template
 and the CyberDemon's C++ example program from GameDev.ru
 (Note: you cannot use program examples from http://gamedev.ru/
  unless you can read in Russian)

 Author      : Cheb, compiled from Jan Horn's and CyberDemon's works
 Email       : cheb@internets.ru
 Website     : http://www.sulaco.co.za  (site on which this example is published)
               http://chebmaster.narod.ru/  (Cheb's site)
 Date        : 06 September 2002
 Version     : n/a
 Description : Examples hardware bump mapping on GeForce1 or any other
               video card, supporting NV_REGISTER_COMBINERS extension

 Adobe Photoshop plugin for making bump textures from height maps
 is available on nVidia site http://developer.nvidia.com/ - dig deeper,
 and you will find it. :)

P.S. There may be much more complex effects, but my GeForce2 has only 2
 texture units, and supports only 2 combiners at time - so any more
 complex effect would take two or more passes, and I didn't bothered
 implementing them.
If you have GeForce 3 or 4, you may try to experiment - I think, these
 video cards should have more texture units and combiners...
------------------------------------------------------------------------

 Controls: Space switches shiny mode,
 Enter switches lighting mode,
 "A": slower, "S" faster.

 ------------------------------------------------------------------------