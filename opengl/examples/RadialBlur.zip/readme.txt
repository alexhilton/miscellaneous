Radial Blur
-----------

This program was originally created by Dario Corno (http://www.spinningkids.org/rio) for Tutorial 37 on nehe.gamedev.net. This is the Delphi conversion for the tutorial.

The tutorial demonstrates how to do an eye candy effect (used in demos) that looks like radial blur. Sometimes it's referred to as volumetric lights, don't believe it, it's just a fake radial blur! ;D 

Radial blur was usually done (when there were only software renderers) by blurring every pixel of the original image in a direction opposite the center of the blur. 

With todays hardware it is quite difficult to do blurring by hand using the color buffer (at least in a way that is supported by all the gfx cards), so we need to do a little trick to achieve the same effect. 


If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
