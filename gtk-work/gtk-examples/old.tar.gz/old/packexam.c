/*
 * packexam.c
 *
 * another packing example
 */
#include <gtk/gtk.h>

void closeApp( GtkWidget *widnow, gpointer data ) {
  gtk_main_quit();
}

void buildWindow( const gchar *title, gboolean fill ) {
  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *button;

  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_title( GTK_WINDOW( window ), title );
  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeApp ), NULL );
  box = gtk_hbox_new( TRUE, 5 );
  gtk_container_set_border_width( GTK_CONTAINER( box ), 5 );

  button = gtk_button_new_with_label( "tiny" );
  gtk_box_pack_start( GTK_BOX( box ), button, FALSE, fill, 5 );
  gtk_widget_show( button );

  button = gtk_button_new_with_label( "medium" );
  gtk_box_pack_start( GTK_BOX( box ), button, FALSE, fill, 5 );
  gtk_widget_show( button );

  gtk_container_add( GTK_CONTAINER( window ), box );
  gtk_widget_show( box );
  gtk_widget_show( window );

}

gint main( gint argc, gchar *argv[] ) {
  gtk_init( &argc, &argv );
  buildWindow( "Homogenous, fill = FALSE", FALSE );
  buildWindow( "Homogenous, fill = TRUE", TRUE );

  gtk_main();
  return 0;
}
