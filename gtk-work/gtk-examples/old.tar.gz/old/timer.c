/*
 * timer.c
 *
 * A small program to check out the timer library.
 */
#include <glib.h>

gint main( gint argc, gchar *argv[] ) {
  GTimer *myTimer;
  myTimer = g_timer_new();
  gint i;
  gdouble time;
  /*while ( bStillNeedToTimeStuff ) {*/
    g_timer_start( myTimer );

    for ( i = 0; i < 19999; i++ )
      ;
    g_timer_stop( myTimer );
    g_timer_reset( myTimer );
    time = g_timer_elapsed( myTimer, NULL );
    g_print( "Elapsed Time: %g\n", time );
  /*}*/
  g_timer_destroy( myTimer );
  return 0;
}
