/*
 * memory.c
 *
 * A small application showing memory allocation with GLIB.
 */
#include <glib.h>

gint main( gint argc, gchar *argv[] ) {
  gpointer mblock; /* gpointer == void * */
  gchar *lptr;
  gint i;

  g_print( "Allocating 51 Bytes of memory\n" );
  mblock = g_malloc( 51 );
  lptr = ( gchar * ) mblock;

  for ( i = 0; i < 50; i++ ) {
    *lptr++ = '*';
  }
  *lptr = '\0';

  g_print( "The 51 bytes of memory hole the following: %s\n",
	   ( gchar * ) mblock );
  g_free( mblock );
  return 0;
}
