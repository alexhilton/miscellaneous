/*
 * boxinterface.c
 *
 * a litle complicated program demonstrating interfaces with
 * GLib.
 */
#include <gtk/gtk.h>

void closeApp( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

GtkWidget *makeWindow() {
  GtkWidget *window;

  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_container_set_border_width( GTK_CONTAINER( window ), 10 );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 80 );
  gtk_window_set_title( GTK_WINDOW( window ), "More advanced User Interfaces" );
  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeApp ), NULL );
  return window;
}

GtkWidget *makeEntryBox() {
  GtkWidget *box;
  GtkWidget *widget;

  box = gtk_hbox_new( TRUE, 5 );
  widget = gtk_label_new( "Please enter your name" );
  gtk_box_pack_start( GTK_BOX( box ), widget, FALSE, TRUE, 0 );

  widget = gtk_entry_new();
  gtk_box_pack_start( GTK_BOX( box ), widget, FALSE, TRUE, 0 );

  return 0;
}

GtkWidget *makeButton() {
  GtkWidget *box;
  GtkWidget *button;

  box = gtk_hbox_new( TRUE, 5 );

  button = gtk_button_new_with_label( "OK" );
  gtk_box_pack_end( GTK_BOX( box ), button, FALSE, TRUE, 0 );
  button = gtk_button_new_with_label( "Cancel" );
  gtk_box_pack_end( GTK_BOX( box ), button, FALSE, TRUE, 0 );

  return box;
}

gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;
  GtkWidget *mainBox;
  GtkWidget *entryBox;
  GtkWidget *buttonBox;
  gtk_init( &argc, &argv );

  window = makeWindow();
  entryBox = makeEntryBox();
  buttonBox = makeButton();

  mainBox = gtk_vbox_new( FALSE, 0 );
  gtk_box_pack_start( GTK_BOX( mainBox ), entryBox, FALSE, FALSE, 0 );
  gtk_box_pack_start( GTK_BOX( mainBox ), buttonBox, FALSE, FALSE, 0 );

  gtk_container_add( GTK_CONTAINER( window ), mainBox );
  gtk_widget_show_all( window );

  gtk_main();
  return 0;
}
