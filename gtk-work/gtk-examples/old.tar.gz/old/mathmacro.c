/*
 * mathmacro.c
 * check out Macros in Math
 * A test program to show how to use some of the math macros in GLIB
 */
#include <glib.h>
#include <stdio.h>

gint main( gint argc, gchar *argv[] ) {
  gint lower_clamp, upper_clamp, test_number;

  g_print( "Enter lower clamp number: " );
  scanf( "%d", &lower_clamp );

  g_print( "Now Enter your upper clamp number : " );
  scanf ( "%d", &upper_clamp );

  g_print( "Finally, enter the number you want to clamp : " );
  scanf( "%d", &test_number );

  g_print( "The lower number is %d\n", MIN( lower_clamp, MIN( upper_clamp, test_number ) ) );
  g_print( "The highest number is %d\n", MAX( lower_clamp, MAX( upper_clamp, test_number ) ) );

  g_print( "Clamped, the %d you entered becomes %d.\n", test_number, CLAMP( test_number, lower_clamp, upper_clamp ) );

  return 0;
}
