/*
 * wposition.c
 *
 * A simple program showing the differences in window positioning.
 * and some tricks to position a window in Glib.
 */
#include <gtk/gtk.h>

void closeWindow( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

void buildWindow( const gchar *title, GtkWindowPosition position ) {
  GtkWidget *window;

  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_position( GTK_WINDOW( window ), position );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 200 );
  gtk_window_set_title( GTK_WINDOW( window ), title );

  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeWindow ), NULL );
  gtk_widget_show( window );
}

gint main( gint argc, gchar *argv[] ) {
  gtk_init( &argc, &argv );

  buildWindow( "Normal", GTK_WIN_POS_NONE );
  buildWindow( "Center", GTK_WIN_POS_CENTER );
  buildWindow( "Mouse", GTK_WIN_POS_MOUSE );

  gtk_main();
  return 0;
}
