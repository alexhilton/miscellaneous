/*
 * button.c
 *
 * Program to demonstrate adding a button to a container, and hooking
 * events to it.
 */
#include <gtk/gtk.h>

/*
 * addButton()
 *
 * Adds a button to the widget specified, setting its caption to the string
 * specified. The function returns the created button.
 */
GtkWidget *addButton( GtkWidget *window, const gchar *buttonText ) {
  GtkWidget *button;
  button = gtk_button_new_with_label( buttonText );
  gtk_container_add( GTK_CONTAINER( window ), button );
  gtk_widget_show( button );

  return button;
}

/*
 * events handler 
 */
void buttonClicked( GtkButton *button, gpointer data ) {
  g_print( "Button got clicked\n" );
}

void stopApp( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

/* main program */
gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;
  GtkWidget *button;

  gtk_init( &argc, &argv );

  /* create the window and give it a default size */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 200 );

  /* set the empty space to insert around any added widgets to 5 pixels */
  gtk_container_border_width( GTK_CONTAINER( window ), 5 );

  /* use our addButton function to create a new button */
  button = addButton( window, "Click Me" );

  /* show the window, and hook its destroy signal to close the app */
  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( stopApp ), NULL );

  /* hook the clicked signal on the button to buttonClicked callback */
  gtk_signal_connect( GTK_OBJECT( window ), "clicked",
		      GTK_SIGNAL_FUNC( buttonClicked ), NULL );
  gtk_widget_show( window );

  /* start the GTK+ main loop running */
  gtk_main();
  return 0;
}
