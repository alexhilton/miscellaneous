/*
 * first program of GTK+ programming.
 */
#include <gtk/gtk.h>

/* prototypes */
void CloseRequest( GtkWidget *theWindow, gpointer data );

gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;

  /* Get GTK+ to process the startup arguments */
  gtk_init( &argc, &argv );

  /* Create the app's main window */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );

  /* Connet a window's signal to a signal function */
  gtk_signal_connect( GTK_OBJECT( window ), "destroy", GTK_SIGNAL_FUNC( CloseRequest ), NULL );

  gtk_widget_show( window );

  gtk_main();

  return 0;
}

/**
 * Function to handle a close signal on the window 
 */
void CloseRequest( GtkWidget *theWindow, gpointer data ) {
  gtk_main_quit();
}
