/*
 * labelsample.c
 *
 * a sample program to show how GtkLabels work.
 */
#include <gtk/gtk.h>

void closeWindow( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

/* changeText alternates the text in a label between two strings */
void changeText( GtkButton *button, gpointer data ) {
  static gboolean textType = TRUE;

  if ( textType ) {
    gtk_label_set_text( GTK_LABEL( data ), "Some Text" );
  } else {
    gtk_label_set_text( GTK_LABEL( data ), "More Text" );
  }

  textType = !textType;
}

gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;
  GtkWidget *label;
  GtkWidget *mainbox;
  GtkWidget *button;

  gtk_init( &argc, &argv );

  /* create the window and set its default attributes */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 200 );
  gtk_window_set_title( GTK_WINDOW( window ), "label sample" );
  gtk_container_set_border_width( GTK_CONTAINER( window ), 10 );

  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeWindow ), NULL );

  /* create a box to hold the label, and a button to control it */
  mainbox = gtk_vbox_new( FALSE, 5 );

  /* time to make the label */
  label = gtk_label_new( "A Label" );
  gtk_box_pack_start( GTK_BOX( mainbox ), label, TRUE, TRUE, 5 );

  /* create the button and hook it to the signal handler */
  button = gtk_button_new_with_label( "change text" );
  gtk_box_pack_start( GTK_BOX( mainbox ), button, TRUE, TRUE, 5 );

  gtk_signal_connect( GTK_OBJECT( window ), "clicked",
		      GTK_SIGNAL_FUNC( changeText ), label );

  /* add the box to the window */
  gtk_container_add( GTK_CONTAINER( window ), mainbox );

  /* show the box to the window */
  gtk_widget_show_all( window );

  gtk_main();
  return 0;
}
