/*
 * memory1.c
 *
 * A small application showing memory allocation with Glib.
 */
#include <glib.h>

gint main( gint argc, gchar *argv[] ) {
  gchar *mblock;
  gchar *lptr;
  gint i;

  g_print( "Allocating 51 bytes of memory\n" );
  /*
   * g_new function is sort of like new operator of C++.
   * Its first argument is type, second is size in bytes.
   * It returns a pointer of its first argument type.
   */
  mblock = g_new( char, 51 );
  lptr = mblock;

  for ( i = 0; i < 50; i++ ) {
    *lptr++ = '*';
  }
  *lptr = '\0';

  g_print( "The 51 bytes of memory hold the following: %s\n", mblock );

  g_free( mblock );

  return 0;
}
