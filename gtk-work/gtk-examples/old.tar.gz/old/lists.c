/*
 * lists.c
 *
 * An example application to show every aspect of working with lists provide
 * by Glib.
 */
#include <glib.h>

/*
 * printTheList()
 *
 * A small function to print out the list contents.
 */
void printTheList( gchar *listTitle, GList *theList ) {
  /* First print up the title, to show the user what's going on */
  g_print( "Here's how the list looks after %s\n\n", listTitle );

  /* Reset the list pointer back to the first item of the list */
  theList = g_list_first( theList );

  /* loop for as long as the list pointer is valid */
  while ( theList != NULL ) {
    /* print out the current list item's data */
    g_print( "%s\n", (gchar *) theList->data );

    /* Set the list pointer up to be the next item in the list */
    theList = g_list_next( theList );
  }

  /* print some blank lines out to make the output have some formatting */
  g_print( "\n\n\n" );
}

/*
 * cmp()
 *
 * Glib uses this to sort items in a list. The two parameters are the values of
 * th data members of the list structures to be checked. GLib expects to get 0
 * returned if the items are the same, -1 if the first item should be before the
 * second, and 1 if the second item should be first in the list.
 */
gint cmp( gconstpointer a, gconstpointer b ) {
  return (g_strcasecmp( (const gchar *) a, (const gchar *) b ));
}

/*
 * itermPrinter()
 *
 * A function to get called from g_list_foreach. GLib will automatically call this
 * function repeatedly, passing it each and every data pointer from a list.
 */
void itemPrinter( gpointer listData, gpointer uerData ) {
  g_print( "%s\n", (gchar *) listData );
}

gint main( gint argc, gchar *argv[] ) {
  /* You'll see these used later */
  gchar rodent1[] = { "Drag, the gerbil" };
  gchar rodent2[] = { "Drop, Drag's buddy" };

  /* First, how to build a list */

  /* 
   * Define a GList pointer and set it to NULL -- this indicates there are no
   * items in the list (that's different to creating an empty list though.
   */
  GList *nameList = NULL;

  /* Next, let's add some names into the list */
  nameList = g_list_append( nameList, "Peter, shaper of code" );
  nameList = g_list_append( nameList, "Heather, code-shaper's wife" );
  nameList = g_list_append( nameList, rodent1 );
  nameList = g_list_append( nameList, rodent2 );

  printTheList( "initially adding some items", nameList );

  /*
   * OK, we missed an entry or two, so let's insert them in order of importances.
   */
  nameList = g_list_prepend( nameList, "Louay, programer's tamer" );
  nameList = g_list_insert( nameList, "John, writer of checks", 1 );

  printTheList( "prepending and inserting some items", nameList );

  /* Now, sort the list and print it out */
  /* 
   * question: what the hell is GComareFunc ?
   */
  nameList = g_list_sort( nameList, (GCompareFunc) cmp );
  printTheList( "sorting the list", nameList );

  /* Now, let's try printing the list out using its own foreach function */
  g_print( "Printing the list now, using g_list_foreach() \n\n" );

  /*
   * Call foreach. Need to pass in the list pointer, the function to use for
   * each item in the list, and a pointer to some user defined data.
   */
  /*
   * question: what the hell is GFunc ?
   */
  g_list_foreach( nameList, (GFunc) itemPrinter, NULL );

  g_print( "\n\n\n" );

  /* Now let's get rid of the rodents */
  nameList = g_list_remove( nameList, rodent1 );
  nameList = g_list_remove( nameList, rodent2 );

  printTheList( "removing the rodents", nameList );

  /* finally, we can free the memory used by the list */
  g_list_free( nameList );

  g_print( "Hey look -- now the list is in the order of importance too. \n" );

  return 0;
}
