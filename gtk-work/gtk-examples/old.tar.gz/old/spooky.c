/*
 * spooky.c
 *
 * Program to print out user information in a spooky way.
 */
#include <stdlib.h>
#include <glib.h>
#include <string.h>
#include <time.h>

void spookyDump( gchar *text ) {
  gdouble time;
  gint i, len = strlen( text );
  GTimer *dumpTimer;
  gint delay;

  dumpTimer = g_timer_new();
  time = g_timer_elapsed( dumpTimer, NULL );

  for ( i = 0; i < len; i++ ) {
    delay = rand() % 3;

    /*
     * The following loop just sits and waits. I know its now a nice
     * thing to do in multitasking environment, and there are more
     * elegant ways of doing this in the real world. It's just here
     * though to demonstrate timers.
     */
    while ( ((g_timer_elapsed(dumpTimer, NULL)-time)*10) < delay )
      ;
    g_print( "%c", text[ i ] );
    time = g_timer_elapsed( dumpTimer, NULL );
  }
  g_timer_stop( dumpTimer );
  g_timer_destroy( dumpTimer );
}

gint main( gint argc, gchar *argv[] ) {
  gchar *outputstr;
  g_print( "*** ALERT - TERMINAL ACCOUNT HAS BEEN COMPROMISED ***\n\n" );

  outputstr = g_strjoin( " ", "Initiating user scan\n", "user is \t:",
			 g_get_real_name(), " aka", g_get_user_name(), "\n",
			 "Files stored at: ", g_get_home_dir(), "\n",
			 "Commercing password decrypt..........\n\n", NULL );
  spookyDump( outputstr );
  g_free( outputstr );
  g_print( "Just Kidding! (hehehe)\n" );
  
  return 0;
}
