/**
 * basicgtk.c
 * 
 * The most basic, non functioning GTK+ application you will ever
 * come accross
 */
#include <gtk/gtk.h>

gint main( gint argc, gchar *argv[] ) {
  /* Declare a GtkWidget to use as the main window */
  GtkWidget *the_window;

  /* 
   * Start GTK+ up, and let it process any arguments that were
   * passed in on the command lines 
   */
  gtk_init( &argc, &argv ); 

  /* Create the window itself */
  the_window =  gtk_window_new( GTK_WINDOW_TOPLEVEL );

  /* 
   * Show the window, as far as GTK+ is concerned though, we just 
   * want to make a widget visible 
   */
  gtk_widget_show( the_window );

  /*
   * Start GTK+ running so that it can catch any signals
   */
  gtk_main();

  /* this line will never be reached in this app */
  return 0;
}
