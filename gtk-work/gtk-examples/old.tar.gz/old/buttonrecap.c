/*
 * buttonrecap.c
 *
 * A simple application to display a button in a window, and respond to all
 * the button's own events/signals. Widget events/signals that occur on
 * the button are ignored( remember, a button derives functionality from a
 * standard widget).
 */
#include <gtk/gtk.h>

void closeWindow( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

void buttonEvent( GtkButton *button, gpointer data ) {
  g_print( "the button was " );
  g_print( (gchar *) data );
  g_print( "\n" );
}

gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;
  GtkWidget *button;

  gtk_init( &argc, &argv );

  /* create the window, and show it */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_default_size( GTK_WINDOW( window ), 160, 100 );
  gtk_window_set_title( GTK_WINDOW( window ), "Button recap" );
  gtk_signal_connect( GTK_OBJECT( window ), "destroy", 
		      GTK_SIGNAL_FUNC( closeWindow ), NULL );

  /* create the button, and connect its signal */
  button = gtk_button_new_with_label( "Button" );

  gtk_signal_connect( GTK_OBJECT( window ), "pressed", 
		      GTK_SIGNAL_FUNC( buttonEvent ), "pressed" );
  gtk_signal_connect( GTK_OBJECT( window ), "released",
		      GTK_SIGNAL_FUNC( buttonEvent ), "released" );
  gtk_signal_connect( GTK_OBJECT( window ), "clicked",
		      GTK_SIGNAL_FUNC( buttonEvent ), "clicked" );
  gtk_signal_connect( GTK_OBJECT( window ), "enter",
		      GTK_SIGNAL_FUNC( buttonEvent ), "entered" );
  gtk_signal_connect( GTK_OBJECT( window ), "leave",
		      GTK_SIGNAL_FUNC( buttonEvent ), "left" );

  /* add the button to the container, and show it */
  gtk_container_add( GTK_CONTAINER( window ), button );
  gtk_widget_show( button );
  gtk_widget_show( window );

  gtk_main();
  return 0;
}
