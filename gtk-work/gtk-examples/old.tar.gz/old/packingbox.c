/*
 * packingbox.c
 *
 * example program to show how packing boxes work.
 */
#include <gtk/gtk.h>

void closeWindow( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

gint main( gint argc, gchar *argv[] ) {
  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *button;

  gtk_init( &argc, &argv );

  /* create a window and set up its size, title and container border */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_container_set_border_width( GTK_CONTAINER( window ), 10 );
  gtk_window_set_title( GTK_WINDOW( window ), "Packing Box Example" );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 50 );

  /* create a new box, horizontal, 5 pixels between any widgets added */
  box = gtk_hbox_new( TRUE, 5 );

  /* create a new button an add it to the box */
  button = gtk_button_new_with_label( "OK" );
  gtk_box_pack_start( GTK_BOX( box ), button, FALSE, TRUE, 0 );
  gtk_widget_show( button );

  /* create a second button and add that as well */
  button = gtk_button_new_with_label( "Cancel" );
  gtk_box_pack_start( GTK_BOX( box ), button, FALSE, TRUE, 0 );
  gtk_widget_show( button );

  /* connect the window's destroy signal to the signal handler function */
  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeWindow ), NULL );

  /* add the GtkBox to the window */
  gtk_container_add( GTK_CONTAINER( window ), box );

  /*
   * show the box, which in turn makes certain any visible widgets it
   * holds come into view 
   */
  gtk_widget_show( box );

  /* show the window, thus showing the box and any visible widgets in it */
  gtk_widget_show( window );

  gtk_main();

  return 0;
}
