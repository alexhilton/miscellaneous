/*
 * events.c
 *
 * A small program to show events in action.
 */
#include <gtk/gtk.h>

/* signal handler for the main window's destroy signal */
void stopApp( GtkWidget *myWindow, gpointer data ) {
  gtk_main_quit();
}

gboolean eventHandler( GtkWidget *myWindow, GdkEvent *event, gpointer data ) {
  /*
   * Examine the type member of the event structure to figure out
   * what kind of event occured.
   */
  switch ( event->type ) {
  case GDK_CONFIGURE:
    g_print( "The window is being re-configured\n" );
    break;
  case GDK_EXPOSE:
    g_print( "The window contents were redrawn\n" );
    break;
  case GDK_ENTER_NOTIFY:
    g_print( "The mouse entered the window\n" );
    break;
  case GDK_LEAVE_NOTIFY:
    g_print( "the mouse left the window\n" );
    break;
  case GDK_DELETE:
    g_print( "Uh oh - the user killed the window\n" );
    break;
  case GDK_MOTION_NOTIFY:
    g_print( "the mouse is moving in the window\n" );
    break;
  case GDK_BUTTON_PRESS:
    g_print( "the mouse is clicking down\n" );
    break;
  case GDK_BUTTON_RELEASE:
    g_print( "the mouse is releasing\n" );
    break;
    /*
     * 'type' is an enumeration -- we need a default: case in order to
     * prevent the compiler complaining that we didn't check for every
     * possible value 
     */
  default:
    break;
  }
  return FALSE;
}

/* main program */
gint main( gint argc, gchar *argv[] ) {
  /* set up a new window pointer for main window */
  GtkWidget *myWindow;

  /*
   * initializing GTK+, passing in the command line parameters so that
   * GTK+ can remove the ones it needs. if any
   */
  gtk_init( &argc, &argv );

  /* create a new window */
  myWindow = gtk_window_new( GTK_WINDOW_TOPLEVEL );

  /*
   * connect up eventhandler() to deal with generic events on the
   * main window
   */
  gtk_signal_connect( GTK_OBJECT( myWindow ), "event",
		      GTK_SIGNAL_FUNC( eventHandler ), NULL );

  /* connect up stopApp() to cope with the window's destroy signal */
  gtk_signal_connect( GTK_OBJECT( myWindow ), "destroy",
		      GTK_SIGNAL_FUNC( stopApp ), NULL );

  /* show the window */
  gtk_widget_show( myWindow );

  /* start the main loop, and event processing */
  gtk_main();

  /* main finished, so now we can stop the application */
  return 0;
}
