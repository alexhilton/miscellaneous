/*
 * table.c
 *
 * A short application to show how to use a table with default packing
 * values.
 */
#include <gtk/gtk.h>

/* signal handler for the window closing */
void closeApp( GtkWidget *window, gpointer data ) {
  gtk_main_quit();
}

/* utility function to create buttons in a table */
void createButtonInTable( GtkWidget *table, const gchar *caption,
			  gint left, gint right, gint top, gint bottom ) {
  GtkWidget *button;

  button = gtk_button_new_with_label( caption );
  gtk_table_attach_defaults( GTK_TABLE( table ), button, left, right, top, bottom );
}

/* the main program */
gint main( gint argc, gchar *argv[] ) {
  /* set up a widget pointer for the window itself */
  GtkWidget *window;
  /* set up a table pointer for the table */
  GtkWidget *table;

  gtk_init( &argc, &argv );

  /* Create the window in the usual way */
  window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
  gtk_window_set_title( GTK_WINDOW( window ), "Fun with tables" );
  gtk_window_set_default_size( GTK_WINDOW( window ), 320, 200 );
  gtk_container_set_border_width( GTK_CONTAINER( window ), 10 );

  /* connect up the destroy signal to its handler */
  gtk_signal_connect( GTK_OBJECT( window ), "destroy",
		      GTK_SIGNAL_FUNC( closeApp ), NULL );

  /* now the table - lets have a 10 by 10, homogenous table */
  table = gtk_table_new( 10, 10, TRUE );

  /* add the table into the window */
  gtk_container_add( GTK_CONTAINER( window ), table );

  /* time to add some buttons to the table now */
  createButtonInTable( table, "Button 1", 0, 1, 0, 1 );
  createButtonInTable( table, "Button 2", 2, 8, 2, 5 );
  createButtonInTable( table, "Button 3", 9, 10, 9, 10 );
  createButtonInTable( table, "Button 4", 7, 8, 5, 9 );

  /* finally, show everything and start the main loop running */
  gtk_widget_show_all( window );

  gtk_main();
  return 0;
}
