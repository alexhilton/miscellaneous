/**
 * dirtree.c
 * Simple program to break down the path in a fully qualified filename.
 */
/*
 * is there some difference.
 */
#include <glib.h>
#include <string.h>

void show_tree( const gchar *filename ) {
  int i;
  int indent = 0;
  int length = strlen( filename );

  for ( i = 0; i < length; i++ ) {
    if ( filename[ i ] != G_DIR_SEPARATOR ) {
      g_print( "%c", filename[ i ] );
    } else {
      indent++;
      if ( indent == 1 ) {
	g_print( "The director " );
      } else if ( indent == 2 ) {
	g_print( " contains " );
      } else {
	g_print( ", which contains " );
      }
    }
  }
  g_print( "\n" );
}

gint main( gint argc, gchar *argv[] ) {
  if ( argc != 2 ) {
    g_print( "Usage:\n\t%s <filename>\n", argv[ 0 ] );
  } else {
    show_tree( argv[ 1 ] );
  }
  return -1; /* why -1, something wrong */
}
