/*
 * tree.c
 *
 * A small example showing how to use trees in GLib.
 */
#include <glib.h>

gint cmp( gconstpointer a, gconstpointer b ) {
  return ( g_strcasecmp( (gchar *) a, (gchar *) b ) );
}

gint traverseTree( gpointer key, gpointer value, gpointer data ) {

  g_print( "Person: %s    Preferred User Interface : %s\n", 
	   (gchar *) key, (gchar *) value );
  return FALSE; /* a macro by GLib? */
}

gint main( gint argc, gchar *argv[] ) {
  GTree *theTree;

  theTree = g_tree_new( (GCompareFunc) cmp );
  
  g_tree_insert( theTree, "Peter", "GNOME in Windowmaker" );
  g_tree_insert( theTree, "Heather", "KDE and GNOME in Enlightenment" );
  g_tree_insert( theTree, "John", "Windows" );
  g_tree_insert( theTree, "Louay", "Jedi mind control" );

  g_print( "In order traversal coming up\n\n" );
  g_tree_traverse( theTree, traverseTree, G_IN_ORDER, NULL );

  g_print( "\n\n\nPre order traversal now\n\n" );
  g_tree_traverse( theTree, traverseTree, G_PRE_ORDER, NULL );

  g_print( "\n\n\nFinally, post order traversal\n\n" );
  g_tree_traverse( theTree, traverseTree, G_POST_ORDER, NULL );

  g_tree_destroy( theTree );
  return 0;
}
